# 🏭 GUIDE PARAMÉTRAGE ODOO.SH - LA PLUME ARTISANALE
## Système ERP Complet pour Fabrication Textile

---

## 📋 TABLE DES MATIÈRES

1. [Connexion et Accès Initial](#1-connexion-et-accès-initial)
2. [Configuration Entreprise](#2-configuration-entreprise)
3. [Gestion Utilisateurs](#3-gestion-utilisateurs)
4. [Module Inventaire/Stock](#4-module-inventaire-stock)
5. [Module Fabrication (MRP)](#5-module-fabrication-mrp)
6. [Module Achats](#6-module-achats)
7. [Module Ventes](#7-module-ventes)
8. [Module Code-Barres/QR Codes](#8-module-code-barres-qr-codes)
9. [Nomenclatures (BOM)](#9-nomenclatures-bom)
10. [Ordres de Fabrication](#10-ordres-de-fabrication)
11. [Traçabilité](#11-traçabilité)
12. [Configuration Spécifique Textile](#12-configuration-spécifique-textile)
13. [Import Données Existantes](#13-import-données-existantes)
14. [Optimisations et Bonnes Pratiques](#14-optimisations-et-bonnes-pratiques)

---

# 1. CONNEXION ET ACCÈS INITIAL

## 1.1 Première Connexion

### Accéder à votre instance

**URL :** Vous avez reçu une URL du type :
```
https://votre-entreprise.odoo.com
ou
https://votre-entreprise-production-xxxxx.dev.odoo.com
```

**Connexion :**
- [ ] Ouvrez l'URL dans votre navigateur
- [ ] Entrez email administrateur
- [ ] Entrez mot de passe
- [ ] Cliquez "Se connecter"

### Langue et localisation

**Menu :** Paramètres → Général → Langues

- [ ] Activer **Français (FR)**
- [ ] Définir comme langue par défaut
- [ ] Activer format date/heure Europe
- [ ] Fuseau horaire : **Africa/Tunis**

**Menu :** Paramètres → Général → Pays

- [ ] Pays : **Tunisie**
- [ ] Devise : **TND (Dinar Tunisien)**
- [ ] Format adresse tunisien

---

# 2. CONFIGURATION ENTREPRISE

## 2.1 Informations Entreprise

**Menu :** Paramètres → Général → Entreprises → La Plume Artisanale

### Informations générales

```
Nom entreprise : La Plume Artisanale
Adresse : [Votre adresse complète]
Code postal : [Code postal]
Ville : [Ville]
Pays : Tunisie
Téléphone : [Téléphone]
Email : [Email contact]
Site web : [Si applicable]
```

- [ ] Uploader **logo entreprise** (format PNG/JPG, 300x150px recommandé)
- [ ] Renseigner **numéro fiscal** (matricule fiscal tunisien)
- [ ] Renseigner **registre commerce**

### Configuration comptable

**Menu :** Paramètres → Comptabilité

- [ ] Plan comptable : **Tunisien**
- [ ] TVA par défaut : **19%** (ou selon votre régime)
- [ ] Exercice fiscal : Du 1er janvier au 31 décembre

---

# 3. GESTION UTILISATEURS

## 3.1 Créer les Utilisateurs

**Menu :** Paramètres → Utilisateurs & Entreprises → Utilisateurs

### Types d'utilisateurs à créer

#### 1. Administrateur Système (vous)

```
Nom : [Votre nom]
Email : [Votre email]
Type accès : Administrateur
Droits : Tous
```

#### 2. Responsable Production

```
Nom : [Nom responsable]
Email : [Email]
Type accès : Standard
Droits à activer :
  ☑ Fabrication / Gestionnaire
  ☑ Inventaire / Gestionnaire
  ☑ Achats / Utilisateur
  ☑ Ventes / Utilisateur
  ☐ Comptabilité (pas nécessaire)
```

#### 3. Responsable Achats/Stock

```
Nom : [Nom responsable]
Email : [Email]
Type accès : Standard
Droits à activer :
  ☑ Achats / Gestionnaire
  ☑ Inventaire / Gestionnaire
  ☑ Fabrication / Utilisateur
  ☐ Ventes
```

#### 4. Magasinier/Opérateur Entrepôt

```
Nom : [Nom magasinier]
Email : [Email] (ou créer email dédié)
Type accès : Standard
Droits à activer :
  ☑ Inventaire / Utilisateur
  ☑ Code-barres / Utilisateur
  ☐ Achats
  ☐ Ventes
  ☐ Fabrication
```

#### 5. Opérateur Production (Tisseurs, Coupeurs)

```
Nom : [Nom opérateur]
Email : [Email]
Type accès : Standard (ou Portail si accès limité)
Droits à activer :
  ☑ Fabrication / Utilisateur
  ☑ Code-barres / Utilisateur (pour scan)
  ☐ Inventaire (vision seulement)
```

#### 6. Contrôleur Qualité

```
Nom : [Nom contrôleur]
Email : [Email]
Type accès : Standard
Droits à activer :
  ☑ Qualité / Utilisateur
  ☑ Fabrication / Utilisateur
  ☑ Inventaire / Utilisateur
```

### Actions

- [ ] Créer tous les utilisateurs nécessaires
- [ ] Leur envoyer invitation par email
- [ ] Vérifier première connexion de chacun
- [ ] Tester droits d'accès

---

# 4. MODULE INVENTAIRE/STOCK

## 4.1 Activation du Module

**Menu :** Applications → Rechercher "Inventaire"

- [ ] Installer **Inventaire**
- [ ] Attendre fin installation (quelques minutes)

## 4.2 Configuration Entrepôts

**Menu :** Inventaire → Configuration → Entrepôts

### Créer vos entrepôts

#### Entrepôt 1 (E1)

```
Nom : E1 - Entrepôt 1
Nom court : E1
Adresse : [Adresse E1]
```

**Configuration avancée :**
- [ ] Réceptions en 1 étape (par défaut)
- [ ] Livraisons en 1 étape (par défaut)
- [ ] Activer "Réapprovisionner depuis d'autres entrepôts"

#### Entrepôt 2 (E2)

```
Nom : E2 - Entrepôt 2
Nom court : E2
Adresse : [Adresse E2]
```

#### Entrepôt 3 (E3)

```
Nom : E3 - Entrepôt 3
Nom court : E3
Adresse : [Adresse E3]
```

#### Usine - Production

```
Nom : Usine - Zone Production
Nom court : USINE
Adresse : [Adresse usine]
Type : Entrepôt de production
```

**Configuration spécifique :**
- [ ] Activer "Gestion par Lots/Numéros de série"
- [ ] Activer "Traçabilité complète"

### Emplacements de stock

**Menu :** Inventaire → Configuration → Emplacements

Pour chaque entrepôt, créer structure :

```
E1
├── E1/Stock (emplacement stockage)
├── E1/Input (réception)
├── E1/Output (expédition)
└── E1/Quality (contrôle qualité)

E2
├── E2/Stock
├── E2/Input
└── E2/Output

E3
├── E3/Stock
├── E3/Input
└── E3/Output

USINE
├── USINE/Stock
├── USINE/Production (en cours de fabrication)
├── USINE/Tissage
├── USINE/Coupe
├── USINE/Finition
└── USINE/Qualité
```

**Actions :**
- [ ] Créer emplacements pour chaque entrepôt
- [ ] Définir emplacements par défaut
- [ ] Activer codes-barres emplacements si souhaité

## 4.3 Configuration Unités de Mesure

**Menu :** Inventaire → Configuration → Unités de Mesure

### Catégories nécessaires

#### Catégorie : Poids

```
Unités à activer :
☑ kg (kilogramme) - Unité de référence
☑ g (gramme)
☑ tonne (si nécessaire)
```

#### Catégorie : Longueur

```
Unités à activer :
☑ m (mètre) - Unité de référence
☑ cm (centimètre)
☑ mm (millimètre)
```

#### Catégorie : Unités

```
☑ Unité(s) - Pour produits finis (pièces)
```

**Actions :**
- [ ] Vérifier unités actives
- [ ] Créer unités personnalisées si besoin
- [ ] Définir conversions automatiques

## 4.4 Configuration Routes de Réapprovisionnement

**Menu :** Inventaire → Configuration → Routes

### Route : Transfert Inter-Entrepôts

**Exemple : E1 → USINE**

```
Nom : Transfert E1 vers Usine
Type : Réapprovisionnement
```

**Règles :**
1. **Règle Pull :**
   - Départ : E1/Output
   - Destination : USINE/Input
   - Action : Tirer depuis

2. **Règle Push :**
   - Départ : E1/Stock
   - Destination : E1/Output
   - Action : Pousser vers

**Répéter pour :**
- [ ] E1 → USINE
- [ ] E2 → USINE
- [ ] E3 → USINE
- [ ] USINE → E1 (retours)

---

# 5. MODULE FABRICATION (MRP)

## 5.1 Activation et Configuration

**Menu :** Applications → Rechercher "Fabrication"

- [ ] Installer **Fabrication (MRP)**
- [ ] Attendre installation

**Menu :** Fabrication → Configuration → Paramètres

### Paramètres à activer

```
☑ Ordres de travail
☑ Gammes de fabrication
☑ Sous-produits
☑ Ordres de fabrication en plusieurs étapes
☑ Nomenclatures multi-niveaux
☑ Gestion des variantes dans les nomenclatures
☑ Traçabilité des matières premières
☑ Lots et numéros de série
☑ Postes de charge
```

- [ ] Sauvegarder

## 5.2 Centres de Travail (Machines)

**Menu :** Fabrication → Configuration → Centres de Travail

### Créer vos centres de travail

#### Groupe : Atelier Tissage

**Centre de travail : M2301**

```
Nom : Machine M2301 - HTVS4/S #36525
Code : M2301
Centre de coûts : Tissage
Capacité : 1 (une machine)
Temps avant production (Setup) : 30 minutes
Temps après production : 15 minutes

Coût horaire : [Coût si suivi financier]
Rendement : 100%

Notes :
- Type : HTVS4/S
- Système : Cadre
- Laize : 100 cm
- Vitesse : 230 duites/min
- Facteur compteur : 1
- Unité compteur : Rapport
```

**Important :** Dans "Notes" ou champ personnalisé, documenter :
- Vitesse (duites/min) → ESSENTIEL pour calculs
- Facteur compteur
- Laize actuelle
- Système (Cadre/Jacquard/Éponge)

**Répéter pour toutes les machines :**

- [ ] M2301 (HTVS4/S, 230 duites/min, Rapport)
- [ ] M2302 (HTVS6/S, 250 duites/min, Rapport)
- [ ] M2303 (HTVS4/S, 260 duites/min, Rapport)
- [ ] M2304 (GTN6/SD, 180 duites/min, Rapport)
- [ ] M2305 (HTV8/S, 190 duites/min, Mètre)
- [ ] M2306 (HTV8/S, 210 duites/min, Mètre)
- [ ] M2307 (HTV4/SD, 180 duites/min, Mètre)
- [ ] M2308 à M2312 (...)
- [ ] M2401 à M2405 (...)

#### Groupe : Atelier Coupe

**Centre de travail : Poste Coupe**

```
Nom : Atelier Coupe
Code : COUPE-01
Capacité : 2 (deux coupeurs)
Temps avant production : 10 minutes
Temps production : [Variable selon produit]
```

#### Groupe : Atelier Finition

**Centre de travail : Poste Finition**

```
Nom : Atelier Finition (Frange/Couture)
Code : FINITION-01
Capacité : 3
```

#### Groupe : Contrôle Qualité

**Centre de travail : Contrôle Qualité**

```
Nom : Poste Contrôle Qualité
Code : QUALITE-01
Capacité : 2
```

**Actions :**
- [ ] Créer tous les centres de travail
- [ ] Grouper par atelier
- [ ] Documenter caractéristiques machines dans notes

---

# 6. MODULE ACHATS

## 6.1 Activation

**Menu :** Applications → Rechercher "Achats"

- [ ] Installer **Achats**

## 6.2 Configuration Fournisseurs

**Menu :** Achats → Fournisseurs → Créer

### Créer vos fournisseurs de fils

**Fournisseur Exemple :**

```
Nom : [Nom fournisseur fils]
Type : Fournisseur
Adresse : [Adresse complète]
Pays : [Pays]
Email : [Email]
Téléphone : [Téléphone]

Conditions de paiement : [Ex: 30 jours fin de mois]
Devise : [TND ou autre]
```

**Actions :**
- [ ] Créer tous vos fournisseurs principaux de MP
- [ ] Fournisseurs de fournitures (boutons, élastiques, etc.)
- [ ] Sous-traitants (Chokri Haddad, Wajdi, Lotfi Tilouche, Dimatex)

---

# 7. MODULE VENTES

## 7.1 Activation

**Menu :** Applications → Rechercher "Ventes"

- [ ] Installer **Ventes**

## 7.2 Configuration Clients

**Menu :** Ventes → Clients → Créer

### Créer vos clients

**Client Exemple :**

```
Nom : [Nom client]
Type : Client
Adresse de facturation : [Adresse]
Adresse de livraison : [Adresse si différente]
Email : [Email]
Téléphone : [Téléphone]

Conditions de paiement : [Conditions]
```

**Client spécial : STOCK**

```
Nom : STOCK - Fabrication pour Stock
Type : Client interne
```

→ Pour les OF destinés au stock (pas de client final)

**Actions :**
- [ ] Créer clients principaux
- [ ] Créer client "STOCK"

---

# 8. MODULE CODE-BARRES / QR CODES

## 8.1 Activation

**Menu :** Applications → Rechercher "Code-barres"

- [ ] Installer **Code-barres**

## 8.2 Configuration

**Menu :** Inventaire → Configuration → Paramètres → Code-barres

```
☑ Activer l'interface code-barres
☑ Scanner avec caméra
☑ Scanner avec lecteur USB
☑ Imprimer étiquettes produits
☑ Imprimer étiquettes emplacements
```

## 8.3 Nomenclature Code-barres

**Menu :** Inventaire → Configuration → Nomenclature Code-barres

### Nomenclature personnalisée pour QR MP

**Créer règle :**

```
Nom de règle : QR Matière Première
Type : Article
Encodage : Code128 ou QR Code
Pattern : [Personnalisé selon votre format]
```

**Votre format actuel :**
```
C01_BLANC_NM15-01.00_S2023__
```

**Actions :**
- [ ] Créer nomenclature QR MP
- [ ] Créer nomenclature OF (CA250023)
- [ ] Tester scan quelques codes

---

# 9. NOMENCLATURES (BOM)

## 9.1 Catégories d'Articles

**Menu :** Inventaire → Configuration → Catégories de Produits

### Créer structure de catégories

```
📁 Matières Premières
   📁 Fils
      📁 NM05 (Numéro métrique 05)
      📁 NM12
      📁 NM15
      📁 NM20
   📁 Fournitures
      📁 Boutons
      📁 Élastiques
      📁 Étiquettes

📁 Produits Finis
   📁 Foutas
   📁 Serviettes
   📁 Ponchos
   📁 Autres

📁 Composants Intermédiaires
   📁 Tissus bruts (avant coupe)
```

**Actions :**
- [ ] Créer structure catégories
- [ ] Définir propriétés par catégorie (stockable, achetable, vendable)

## 9.2 Créer les Articles Matières Premières

**Menu :** Inventaire → Produits → Créer

### Article MP - Fil

**Exemple : Fil Blanc NM15 Lot S2023**

```
════════════════════════════════════
ONGLET INFORMATIONS GÉNÉRALES
════════════════════════════════════
Nom du produit : Fil Coton Blanc NM15
Référence interne : C01_BLANC_NM15-01.00_S2023
Code-barres : C01_BLANC_NM15-01.00_S2023__ (votre format QR)

Peut être vendu : ☐ Non
Peut être acheté : ☑ Oui
Peut être fabriqué : ☐ Non

Catégorie de produit : Matières Premières > Fils > NM15
Type de produit : Stockable
Unité de mesure : kg
Unité d'achat : kg

════════════════════════════════════
ONGLET INVENTAIRE
════════════════════════════════════
Règles de logistique :
☑ Routes : Acheter, Fabrication (pour consommation)

Traçabilité :
☑ Par numéro de lot unique
☐ Par numéro de série unique

Numéro de lot : S2023 (à créer)

════════════════════════════════════
ONGLET ACHATS
════════════════════════════════════
Fournisseur : [Sélectionner fournisseur]
Prix d'achat : [Prix au kg]
Délai de livraison : [Ex: 15 jours]

════════════════════════════════════
ONGLET NOTES (Champs personnalisés)
════════════════════════════════════
Code Couleur : C01
Couleur : BLANC
Numéro Métrique : NM15
Code Fabrication MP : NM15-01.00
Couleur Commerciale : Blanc
Num de Lot : S2023
Stock Minimal : 1500 kg (seuil alerte)
```

### Créer tous vos fils

**Liste (exemples de vos données) :**

- [ ] C01_BLANC_NM15-01.00_S2023
- [ ] C01_BLANC_NM15-01.00_63555
- [ ] C01_BLANC_NM15-01.00_63577
- [ ] C02_ECRU_NM05-02.00_60530
- [ ] C02_ECRU_NM12-02.00_S2023
- [ ] C02_Ecru_NM15-02.00_65324
- [ ] C03_BEIGE CLAIR_NM05-03.02_S2023
- [ ] C03_BEIGE CLAIRE_NM15-03.00_65359
- [ ] C04_TAUPE_NM15-04.00_65370
- [ ] ... (tous vos fils)

**💡 Astuce Import :**
Plutôt que créer manuellement, préparez fichier Excel puis import massif (voir section 13).

## 9.3 Créer les Articles Produits Finis

**Menu :** Inventaire → Produits → Créer

### Produit Fini - Fouta

**Exemple : Fouta ARTHUR 100/200 CM Frange Blanc**

```
════════════════════════════════════
ONGLET INFORMATIONS GÉNÉRALES
════════════════════════════════════
Nom du produit : ARTHUR 100/200 Frange Blanc
Référence interne : AR1020(FR)-B
Code-barres : [Générer ou scanner]

Peut être vendu : ☑ Oui
Peut être acheté : ☐ Non
Peut être fabriqué : ☑ Oui

Catégorie de produit : Produits Finis > Foutas
Type de produit : Stockable
Unité de mesure : Unité(s)

════════════════════════════════════
ONGLET INVENTAIRE
════════════════════════════════════
Règles de logistique :
☑ Routes : Fabriquer, Stocker

Traçabilité :
☐ Par numéro de lot unique
☑ Par numéro de série unique (si traçabilité pièce par pièce)
Ou
☑ Par numéro de lot unique (si traçabilité par lot production)

════════════════════════════════════
ONGLET VENTES
════════════════════════════════════
Prix de vente : [Prix unitaire]
```

**Répéter pour tous produits finis :**
- ARTHUR variantes (dimensions, couleurs, finitions)
- IBIZA variantes
- PONCHO variantes
- ...

### Produits Finis COMPOSÉS (plusieurs tissus)

**Exemple : Poncho EN Couture (2 composants : C01 + C02)**

**Produit principal :**
```
Nom : Poncho EN Couture
Référence : PONEN(COU)-COMPOSE
Peut être fabriqué : ☑ Oui
```

→ Aura une nomenclature (BOM) avec 2 composants intermédiaires

**Composant intermédiaire 1 :**
```
Nom : Tissu Poncho EN C01
Référence : PONEN-C01
Peut être fabriqué : ☑ Oui
Catégorie : Composants Intermédiaires
```

**Composant intermédiaire 2 :**
```
Nom : Tissu Poncho EN C02
Référence : PONEN-C02
Peut être fabriqué : ☑ Oui
Catégorie : Composants Intermédiaires
```

## 9.4 Créer les Nomenclatures (BOM)

**Menu :** Fabrication → Produits → Nomenclatures → Créer

### BOM Produit Simple (1 tissu)

**Exemple : Fouta ARTHUR 1020×FR Uni-couleur Blanc**

```
════════════════════════════════════
EN-TÊTE NOMENCLATURE
════════════════════════════════════
Produit : ARTHUR-1020-FR-UNI-BLANC
Quantité produit : 1
Référence nomenclature : BOM/ARTHUR/001 (ou auto)
Type de nomenclature : Fabriquer ce produit
```

```
════════════════════════════════════
ONGLET COMPOSANTS
════════════════════════════════════

Ligne 1 : Sélecteur S01
├─ Produit : [Rechercher par QR MP ou nom]
│   Ex : C01_BLANC_NM15-01.00_S2023 (Fil Coton Blanc)
├─ Quantité : 0,850 kg
│   → Récupéré depuis votre BOM Excel Conso S01
├─ Unité : kg
└─ Opération (optionnel) : Tissage

Ligne 2 : Sélecteur S02
├─ Produit : [QR MP du fil pour S02]
├─ Quantité : 0,420 kg
│   → Conso S02 du BOM
├─ Unité : kg
└─ Opération : Tissage

Ligne 3 : Sélecteur S03
├─ Si utilisé : Ajouter ligne
│   Sinon : Laisser vide (pas de ligne)

... Jusqu'à S08

Ligne N : Fournitures (si applicable)
├─ Produit : Boutons / Élastiques / etc.
├─ Quantité : [selon BOM]
└─ Opération : Finition
```

```
════════════════════════════════════
ONGLET OPÉRATIONS (GAMME DE FABRICATION)
════════════════════════════════════

Opération 1 : Tissage
├─ Centre de travail : [Sélectionner machine ou "Atelier Tissage"]
├─ Durée par défaut (minutes) : [Estimé ou calculé]
│   → Sera calculé dynamiquement par formule si développement
├─ Temps avant production (Setup) : 30 minutes
├─ Temps après production : 15 minutes
└─ Description : Tisser la fouta selon dimensions

Opération 2 : Contrôle Tissage
├─ Centre de travail : Zone Qualité
├─ Durée : 10 minutes
└─ Description : Vérifier défauts tissage

Opération 3 : Coupe
├─ Centre de travail : Atelier Coupe
├─ Durée : 15 minutes
└─ Description : Couper selon gabarit

Opération 4 : Finition
├─ Centre de travail : Atelier Finition
├─ Durée : 20 minutes (selon type finition)
└─ Description : Frange / Couture / Ourlet selon spec

Opération 5 : Contrôle Final
├─ Centre de travail : Zone Qualité
├─ Durée : 5 minutes
└─ Description : Contrôle qualité final
```

**Sauvegarder la nomenclature**

### BOM Produit Composé (plusieurs tissus)

**Exemple : Poncho EN Couture (2 tissus)**

**BOM Niveau 1 : Produit Fini**

```
Produit : Poncho EN Couture
Quantité : 1

Composants :
├─ Ligne 1 : Tissu Poncho EN C01 × 1 unité (Opération : Assemblage)
└─ Ligne 2 : Tissu Poncho EN C02 × 1 unité (Opération : Assemblage)
```

**BOM Niveau 2a : Tissu C01**

```
Produit : Tissu Poncho EN C01
Quantité : 1

Composants :
├─ Sélecteur S01 : Fil [QR MP] × [Conso kg]
├─ Sélecteur S02 : Fil [QR MP] × [Conso kg]
└─ ...

Opérations :
├─ Tissage (Machine Jacquard)
└─ Contrôle Tissage
```

**BOM Niveau 2b : Tissu C02**

```
Produit : Tissu Poncho EN C02
Quantité : 1

Composants :
├─ Sélecteur S01 : Fil [QR MP] × [Conso kg]
└─ ...

Opérations :
└─ Tissage
```

**Actions :**
- [ ] Créer BOM pour tous produits finis
- [ ] Vérifier consommations S01-S08
- [ ] Définir gammes de fabrication (opérations)
- [ ] Tester avec un OF de test

---

# 10. ORDRES DE FABRICATION

## 10.1 Créer un OF Manuel (Test)

**Menu :** Fabrication → Ordres de fabrication → Créer

### Créer OF de test

```
════════════════════════════════════
EN-TÊTE OF
════════════════════════════════════
Produit : [Sélectionner produit fini]
Ex : ARTHUR-1020-FR-UNI-BLANC

Quantité à produire : 10
Nomenclature : [Auto-sélectionnée si une seule BOM]
Date limite : [Date souhaitée]

Référence : [Auto : WH/MO/00001 ou personnaliser]
```

**Personnaliser numéro OF :**

Odoo génère des numéros automatiques (WH/MO/00001), mais vous pouvez les personnaliser.

**Menu :** Paramètres → Technique → Séquences → Rechercher "Ordre de fabrication"

Modifier format :
```
Préfixe : OF
Suffixe : %(year)s
Padding : 6

Résultat : OF245900, OF245901, etc.
```

### Valider OF

- [ ] Cliquer "Confirmer"
- [ ] Odoo va :
  - Réserver les composants (MP)
  - Créer les ordres de travail (opérations)
  - Calculer besoins matières

### Lancer Production

**Onglet Ordres de travail :**

Vous verrez la liste des opérations :
1. Tissage (Machine M2301) - Durée : XX min
2. Contrôle Tissage - Durée : 10 min
3. Coupe - Durée : 15 min
4. Finition - Durée : 20 min
5. Contrôle Final - Durée : 5 min

**Pour chaque opération :**
- [ ] Cliquer "Démarrer" → Enregistre heure début
- [ ] Saisir quantité produite (si partiel)
- [ ] Scanner QR code MP consommées (si traçabilité)
- [ ] Cliquer "Terminer" → Enregistre heure fin

### Enregistrer Production

**Onglet Composants consommés :**
- Vérifier quantités consommées
- Scanner QR MP pour traçabilité lots

**Une fois toutes opérations terminées :**
- [ ] Cliquer "Produire"
- [ ] Odoo :
  - Consomme les MP du stock
  - Ajoute produits finis au stock
  - Clôture l'OF

**Actions :**
- [ ] Créer un OF de test
- [ ] Suivre tout le flux
- [ ] Vérifier mouvements de stock
- [ ] Vérifier traçabilité

---

## 10.2 Créer OF depuis Commande Client

**Menu :** Ventes → Commandes → Créer

### Créer commande

```
Client : [Sélectionner client]
Date commande : [Date]

Lignes de commande :
├─ Produit : ARTHUR-1020-FR-UNI-BLANC
├─ Quantité : 100
└─ Prix unitaire : [Prix]

Date livraison prévue : [Date]
```

**Sauvegarder et Confirmer**

### Générer OF depuis commande

Si le produit a une BOM et route "Fabriquer" :

- [ ] Odoo crée automatiquement l'OF lié
- [ ] Menu Fabrication → Ordres de fabrication
- [ ] Vous verrez OF avec origine : SO/00001 (Sales Order)

**Avantages :**
- Lien OF ↔ Commande client
- Traçabilité complète
- Calcul automatique besoins

---

## 10.3 Gestion Sous-OF (Num Sous OF)

**Votre besoin :** Créer des "Num Sous OF" (CA250023) pour chaque pièce tissée

### Option 1 : Utiliser Numéros de Série

Dans la BOM, pour le produit fini :
```
Traçabilité : Par numéro de série unique
```

Lors de la production :
- [ ] Pour chaque pièce produite, générer un numéro de série
- [ ] Format personnalisé : CA250023, CA250024, etc.

**Menu :** Inventaire → Configuration → Numéros de Lot/Série

Créer séquence :
```
Préfixe : CA
Suffixe : %(year)s
Numéro suivant : 00001
```

### Option 2 : Développement Personnalisé (Module)

Créer module Odoo qui :
- Génère un "Num Sous OF" pour chaque pièce
- Format CA250023
- Lie Num Sous OF → Num OF principal
- QR code imprimable

**Nécessite développeur Odoo** (Python) ou module du marketplace.

---

# 11. TRAÇABILITÉ

## 11.1 Configuration Traçabilité

**Menu :** Inventaire → Configuration → Paramètres

```
☑ Lots et numéros de série
☑ Traçabilité complète
☑ Afficher tous les lots disponibles
```

## 11.2 Créer Lots pour MP

**Menu :** Inventaire → Produits → Lots/Numéros de Série → Créer

### Créer lot pour un fil

```
Numéro de lot : S2023
Produit : C01_BLANC_NM15-01.00_S2023
Référence interne : [Si autre]
Date réception : [Date]
Date péremption : [Si applicable]

Notes : Informations fournisseur
```

**Lors de réception MP :**
- Scanner QR MP
- Odoo détecte produit
- Créer/Affecter lot automatiquement

**Actions :**
- [ ] Créer lots pour MP existantes
- [ ] Configurer création auto lors réception

## 11.3 Traçabilité dans OF

Lors de la production d'un OF :

**Onglet Composants consommés :**
- Pour chaque fil (S01-S08)
- Scanner QR MP
- Odoo enregistre : Lot consommé

**Résultat :**
- Produit fini lié aux lots MP utilisés
- Traçabilité amont : "Quels fils dans ce produit ?"
- Traçabilité aval : "Quels produits contiennent ce lot ?"

## 11.4 Rapport Traçabilité

**Menu :** Inventaire → Rapports → Traçabilité

**Recherche amont :**
```
Produit : [Produit fini]
Numéro de série : [Numéro pièce]

→ Affiche : Tous les lots MP utilisés
```

**Recherche aval :**
```
Lot/Série : S2023 (Lot MP)

→ Affiche : Tous les produits finis contenant ce lot
```

**Actions :**
- [ ] Tester traçabilité sur OF de test
- [ ] Vérifier rapports
- [ ] Former équipe qualité

---

# 12. CONFIGURATION SPÉCIFIQUE TEXTILE

## 12.1 Champs Personnalisés (Studio)

**Si Odoo Studio activé (souvent en cloud) :**

**Menu :** Studio → Activer

### Champs personnalisés pour MP (Fils)

**Menu Studio :** Inventaire → Produits → Ajouter champ

```
Champ : Code Couleur
Type : Texte
Onglet : Informations générales
Requis : Oui
```

**Répéter pour :**
- [ ] Code Couleur
- [ ] Couleur (nom complet)
- [ ] Numéro Métrique (NM05, NM15, etc.)
- [ ] Code Fabrication MP
- [ ] Couleur Commerciale (famille)
- [ ] Stock Minimal (seuil alerte)

### Champs personnalisés pour Machines

**Menu Studio :** Fabrication → Centres de Travail → Ajouter champ

```
Champ : Vitesse (duites/min)
Type : Entier
Requis : Oui
```

**Répéter pour :**
- [ ] Vitesse (duites/min)
- [ ] Facteur Compteur
- [ ] Unité Compteur (Sélection : Mètre / Rapport)
- [ ] Laize actuelle (cm)
- [ ] Système (Sélection : Cadre / Jacquard / Éponge)
- [ ] État (Sélection : En fonction / Hors service)

**Actions :**
- [ ] Créer tous champs personnalisés
- [ ] Remplir pour articles existants
- [ ] Documenter utilisation

## 12.2 Règles Automatiques

**Menu :** Paramètres → Technique → Automatisation → Actions Automatisées

### Règle : Alerte Stock Minimal MP

```
Nom : Alerte Stock < Minimal
Modèle : Produit
Déclencheur : Sur modification
Filtre domaine : [('qty_available', '<', 'stock_minimal')]

Action : Envoyer email
Destinataire : [Responsable achats]
Objet : ⚠️ Stock faible - {{object.name}}
Message : Le stock de {{object.name}} est à {{object.qty_available}} kg, sous le seuil minimal de {{object.stock_minimal}} kg.
```

**Actions :**
- [ ] Créer règles d'alerte
- [ ] Tester déclenchement

---

# 13. IMPORT DONNÉES EXISTANTES

## 13.1 Import Matières Premières

**Préparer fichier Excel :**

**colonnes requises :**
```
| name | default_code | barcode | categ_id | type | uom_id | purchase_ok | sale_ok | produce_delay | list_price | standard_price | code_couleur | couleur | numero_metrique | code_fabrication_mp | num_lot | stock_minimal |
```

**Exemple ligne :**
```
| Fil Coton Blanc NM15 | C01_BLANC_NM15-01.00_S2023 | C01_BLANC_NM15-01.00_S2023__ | Matières Premières > Fils > NM15 | product | kg | True | False | 15 | 0 | [Prix] | C01 | BLANC | NM15 | NM15-01.00 | S2023 | 1500 |
```

**Import :**

**Menu :** Inventaire → Produits → Importer

- [ ] Télécharger template Odoo
- [ ] Adapter vos données au format
- [ ] Importer fichier
- [ ] Vérifier erreurs éventuelles
- [ ] Valider import

## 13.2 Import Produits Finis

**Même processus :**

- [ ] Préparer Excel
- [ ] Importer
- [ ] Vérifier

## 13.3 Import BOM

**Plus complexe**, nécessite :
- Import produits d'abord
- Puis import lignes BOM

**Format BOM :**
```
| product_tmpl_id | product_qty | type | product_id | product_uom_id | product_qty |
```

**Recommandation :**
- Créer BOM manuellement pour les premiers produits
- Utiliser "Dupliquer" pour produits similaires
- Import massif si vraiment nécessaire (>100 BOM)

## 13.4 Import Stocks Initiaux

**Faire inventaire initial :**

**Menu :** Inventaire → Opérations → Ajustements de Stock

### Inventaire E1

- [ ] Créer inventaire : "Inventaire Initial E1"
- [ ] Emplacement : E1/Stock
- [ ] Ajouter tous articles présents
- [ ] Saisir quantités physiques
- [ ] Valider inventaire

**Répéter pour :**
- [ ] E2
- [ ] E3
- [ ] USINE

**Odoo créera mouvements d'ajustement** pour mettre stock à niveau.

---

# 14. OPTIMISATIONS ET BONNES PRATIQUES

## 14.1 Performances

### Archivage

**Archives produits non utilisés :**
- [ ] Inventaire → Produits
- [ ] Filtrer produits obsolètes
- [ ] Action → Archiver

**Archives OF terminés anciens :**
- OF de plus de 2 ans
- Archiver (pas supprimer, pour historique)

### Index

Odoo gère automatiquement, mais vérifier :
- [ ] Index sur champs recherchés fréquemment
- [ ] Nettoyage logs/historique périodique

## 14.2 Sauvegardes

**Odoo.sh gère sauvegardes automatiques**, mais :

**Menu :** Odoo.sh Dashboard → Backups

- [ ] Vérifier fréquence sauvegardes (quotidienne recommandée)
- [ ] Tester restauration sauvegarde (1 fois/an minimum)
- [ ] Télécharger sauvegarde locale régulièrement

## 14.3 Mises à Jour

**Odoo.sh déploie mises à jour automatiquement** :

**Environnements :**
- **Production** : Votre instance live
- **Staging** : Environnement de test (si plan le permet)

**Workflow :**
1. Odoo publie nouvelle version
2. Tester en Staging d'abord
3. Si OK, déployer en Production

**Actions :**
- [ ] Définir processus validation mises à jour
- [ ] Tester fonctionnalités critiques après MAJ
- [ ] Former utilisateurs si nouvelles features

## 14.4 Sécurité

### Mots de passe

- [ ] Imposer mots de passe forts
- [ ] Renouvellement périodique
- [ ] Authentification 2 facteurs (si disponible)

### Droits d'accès

- [ ] Principe du moindre privilège
- [ ] Revue périodique des droits
- [ ] Désactiver comptes inutilisés

### Logs

- [ ] Activer logs d'accès
- [ ] Revue régulière logs
- [ ] Alerte activités suspectes

---

# 15. FORMATION ET SUPPORT

## 15.1 Ressources Odoo

**Documentation officielle :**
- https://www.odoo.com/documentation/17.0/
- https://www.odoo.com/fr_FR/page/docs

**Odoo eLearning :**
- https://www.odoo.com/slides
- Cours gratuits en ligne

**Communauté Odoo :**
- Forum : https://www.odoo.com/forum
- Github : https://github.com/odoo/odoo

## 15.2 Formation Utilisateurs

### Programme formation suggéré

**Jour 1 : Responsables (4 heures)**
- Vue d'ensemble Odoo
- Fabrication : OF, BOM
- Inventaire : Stocks, transferts
- Rapports et KPI

**Jour 2 : Opérateurs (2 heures)**
- Interface code-barres
- Scan QR codes
- Enregistrement production
- Déclaration problèmes

**Jour 3 : Magasiniers (3 heures)**
- Réceptions MP
- Inventaires
- Transferts inter-entrepôts
- Préparation OF

**Actions :**
- [ ] Planifier sessions formation
- [ ] Préparer supports (captures, exemples)
- [ ] Sessions pratiques hands-on
- [ ] Évaluation après formation

## 15.3 Support Odoo.sh

**Selon votre plan :**

**Support Standard :**
- Email support
- Base de connaissances
- Forum communauté

**Support Premium (si souscrit) :**
- Support téléphone
- Chat en direct
- Temps de réponse garanti

**Comment ouvrir ticket :**

**Menu :** Odoo.sh Dashboard → Support

Ou Email : support@odoo.com

**Actions :**
- [ ] Identifier plan support actuel
- [ ] Tester ouverture ticket
- [ ] Documenter contact support

---

# 16. CHECKLIST COMPLÈTE PARAMÉTRAGE

## Phase 1 : Configuration Initiale (Semaine 1)

- [ ] ✅ Connexion instance Odoo.sh
- [ ] ✅ Configuration langue et localisation (Tunisie, Français)
- [ ] ✅ Informations entreprise (logo, adresse, fiscal)
- [ ] ✅ Création utilisateurs (admin, responsables, opérateurs)
- [ ] ✅ Activation modules (Inventaire, Fabrication, Achats, Ventes, Code-barres)

## Phase 2 : Configuration Stock (Semaine 1-2)

- [ ] ✅ Création entrepôts (E1, E2, E3, USINE)
- [ ] ✅ Création emplacements de stock
- [ ] ✅ Configuration unités de mesure (kg, m, unités)
- [ ] ✅ Configuration routes transferts inter-entrepôts
- [ ] ✅ Configuration traçabilité (lots/séries)

## Phase 3 : Configuration Fabrication (Semaine 2)

- [ ] ✅ Paramètres MRP (ordres de travail, gammes, etc.)
- [ ] ✅ Création centres de travail (machines M2301-M2405, ateliers)
- [ ] ✅ Documentation caractéristiques machines (vitesse, facteur compteur)
- [ ] ✅ Configuration nomenclature code-barres

## Phase 4 : Articles et BOM (Semaine 2-3)

- [ ] ✅ Création catégories produits
- [ ] ✅ Création articles MP (fils) - Import massif recommandé
- [ ] ✅ Création lots MP existants
- [ ] ✅ Création articles produits finis
- [ ] ✅ Création BOM (nomenclatures) pour chaque produit
- [ ] ✅ Définition gammes de fabrication (opérations)

## Phase 5 : Partenaires (Semaine 3)

- [ ] ✅ Création fournisseurs MP
- [ ] ✅ Création sous-traitants
- [ ] ✅ Création clients
- [ ] ✅ Configuration conditions de paiement

## Phase 6 : Import Données (Semaine 3-4)

- [ ] ✅ Import matières premières (si pas fait)
- [ ] ✅ Import produits finis (si pas fait)
- [ ] ✅ Inventaires initiaux (E1, E2, E3, USINE)
- [ ] ✅ Vérification cohérence données

## Phase 7 : Tests (Semaine 4)

- [ ] ✅ Création OF de test (produit simple)
- [ ] ✅ Suivi complet OF (tissage, coupe, qualité)
- [ ] ✅ Vérification mouvements stock
- [ ] ✅ Test traçabilité (MP → Produit)
- [ ] ✅ Test scan code-barres
- [ ] ✅ Test transferts inter-entrepôts
- [ ] ✅ Correction bugs/ajustements

## Phase 8 : Formation (Semaine 4-5)

- [ ] ✅ Formation responsables
- [ ] ✅ Formation magasiniers
- [ ] ✅ Formation opérateurs production
- [ ] ✅ Documentation utilisateur
- [ ] ✅ FAQ

## Phase 9 : Pilote (Semaine 5-6)

- [ ] ✅ Sélection périmètre pilote (1 machine, 1 semaine)
- [ ] ✅ Production réelle avec Odoo
- [ ] ✅ Suivi quotidien utilisateurs
- [ ] ✅ Relevé incidents/ajustements
- [ ] ✅ Bilan pilote

## Phase 10 : Déploiement (Semaine 7+)

- [ ] ✅ Corrections post-pilote
- [ ] ✅ Déploiement complet
- [ ] ✅ Support renforcé (J+1 à J+7)
- [ ] ✅ Stabilisation (1 mois)
- [ ] ✅ Optimisations continues

---

# 17. SUPPORT ET PROCHAINES ÉTAPES

## 17.1 Contact

**Questions sur Odoo.sh :**
- Support Odoo : support@odoo.com
- Documentation : https://www.odoo.com/documentation

**Questions sur ce guide :**
- Je suis disponible pour clarifications
- Accompagnement paramétrage si besoin
- Développements personnalisés (modules)

## 17.2 Modules Complémentaires

**Marketplace Odoo :**
- https://apps.odoo.com/

**Modules intéressants pour textile :**
- Manufacturing Order Print (étiquettes OF)
- Advanced Traceability
- Production Planning (Gantt avancé)
- Quality Control Extended
- Stock Alerts

**Actions :**
- [ ] Explorer marketplace
- [ ] Identifier modules utiles
- [ ] Tester en staging avant production

## 17.3 Développements Personnalisés

**Si besoin fonctionnalités spécifiques :**

Exemples :
- Génération Num Sous OF (CA250023)
- Calculs automatiques temps production (avec vitesse machine)
- Intégration SharePoint (import/export)
- Rapports personnalisés
- Workflow spécifiques

**Options :**
1. Développeur Odoo interne (si compétences Python)
2. Freelance Odoo (Upwork, Malt, etc.)
3. Partenaire Odoo officiel (liste sur odoo.com)

---

# CONCLUSION

## ✅ Ce que vous aurez après ce paramétrage

1. **ERP complet et moderne**
   - Gestion production de A à Z
   - Traçabilité totale MP → Produit fini
   - Multi-entrepôts, multi-machines

2. **Workflow optimisé**
   - OF automatiques depuis commandes
   - Scan QR codes à chaque étape
   - Calculs automatiques (besoins, temps)

3. **Visibilité temps réel**
   - États stocks par entrepôt
   - Avancement OF
   - Alertes automatiques

4. **Traçabilité réglementaire**
   - Lots MP → Produits finis
   - Rapports traçabilité en 1 clic
   - Conformité audits/certifications

5. **Évolutivité**
   - Ajouter modules au besoin
   - Scalabilité (croissance entreprise)
   - Support éditeur

## 🎯 Prochaines Étapes Concrètes

**Semaine prochaine :**
1. ✅ Lire ce guide en entier
2. ✅ Se connecter à Odoo.sh
3. ✅ Démarrer Phase 1 (Configuration initiale)
4. ✅ Me contacter si questions

**Mois prochain :**
1. ✅ Paramétrage complet (suivre checklist)
2. ✅ Import données existantes
3. ✅ Tests intensifs
4. ✅ Formation équipes

**Dans 2 mois :**
1. ✅ Déploiement production
2. ✅ Stabilisation
3. ✅ Optimisations

---

**Prêt à transformer votre production avec Odoo ? 🚀**

Si vous avez des questions ou souhaitez un accompagnement personnalisé pour le paramétrage, n'hésitez pas !

**Bon courage et bonne mise en place !** 💪
