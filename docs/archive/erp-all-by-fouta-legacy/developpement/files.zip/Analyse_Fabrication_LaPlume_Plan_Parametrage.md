# 📊 ANALYSE COMPLÈTE - SYSTÈME DE FABRICATION LA PLUME ARTISANALE
## Guide de Paramétrage et Améliorations

---

## 📋 RÉSUMÉ EXÉCUTIF

Ce document compile **l'analyse de toutes nos discussions** sur les fonctionnalités de fabrication textile de La Plume Artisanale. Il présente :

1. ✅ **Fonctionnalités actuellement implémentées** (Excel/Power Query/Web App)
2. 🎯 **Besoins identifiés** pour la production
3. 📝 **Plan de paramétrage structuré**
4. 💡 **Améliorations recommandées**

**Objectif :** Disposer d'un système ERP complet pour gérer la fabrication textile de A à Z.

---

# PARTIE 1 : ANALYSE DES FONCTIONNALITÉS ACTUELLES

## 1.1 GESTION DES COMMANDES

### ✅ Fonctionnalités implémentées

**Sources de données consolidées :**
- Base Commandes 2025-2026
- Base Commandes 2024-2025  
- Catalogue produits
- Fusion automatique avec BaseArticle pour obtenir les références de fabrication

**Données de commande gérées :**
- N° OF (Ordre de Fabrication)
- Code Commercial / Référence client
- Modèle (ARTHUR, IBIZA, PONCHO, etc.)
- Dimensions (converties automatiquement : 1020 → 100/200 CM)
- Quantité commandée
- Quantité réservée
- Quantité à fabriquer (A Fabriquer)
- Reste à fabriquer (calculé dynamiquement)
- Statut commande (En cours, Solder, Annuler)
- Date de livraison
- Priorité

**États gérés :**
- Toutes les lignes affichées (y compris Soldé et Annulé)
- Filtrage possible selon besoins

---

## 1.2 SYSTÈME BOM (NOMENCLATURES)

### ✅ Structure hiérarchique implémentée

**Architecture en 2 tables :**

#### Table 1 : Paramétrage_Master
Contient les **produits finis** avec caractéristiques globales :
- Code paramétrage (identifiant unique)
- Produit
- Modèle
- Code Dimensions
- Type de Finition (Frange/Couture/Ourlet)
- Nombre de couleurs
- Type de Fabrication (Unique/Composer)

#### Table 2 : Paramétrage_Composants
Contient les **composants individuels** à fabriquer :
- Code paramétrage (lien avec Master)
- ID Composant (Unique, C01, C02, C03, etc.)
- Description du composant
- **Qté par Unité** (combien de composants pour 1 produit fini)
- Largeur tissage (cm)
- Longueur tissage (cm)
- Duite par CM
- Nombre de duites total
- **Consommations S01 à S08** (kg par sélecteur)

### ✅ Logique de fusion BOM

**Jointure multi-colonnes sophistiquée :**
```
Clés de jointure :
1. Modèle
2. Code Dimensions  
3. Type de Finition
4. Nombre de couleur
```

**Gestion produits composés :**
- Produit "Unique" → 1 ligne, 1 tissu
- Produit "Composer" → Multiple lignes avec suffixes /1, /2, /3
  - Exemple : OF245900/1 (C01), OF245900/2 (C02)

---

## 1.3 NUMÉROTATION DES ORDRES

### ✅ Système multi-niveaux implémenté

**Niveau 1 : Num OF Principal**
- Format : OF + Numéro séquentiel
- Exemple : OF245900
- Correspond à la commande client

**Niveau 2 : Num OF avec Suffixe**
- Format : Num OF + /X (X = numéro du composant)
- Exemples : OF245900/1, OF245900/2, OF245900/3
- Permet de séparer les composants d'un produit "Composer"

**Niveau 3 : Num Sous OF**
- Format : CA + Année + Numéro séquentiel
- Exemple : CA250023
- Identifiant unique pour **chaque pièce tissée individuellement**
- Permet traçabilité ultra-fine au niveau pièce

---

## 1.4 GESTION MATIÈRES PREMIÈRES

### ✅ Système de traçabilité par QR Code

**Format QR MP standardisé :**
```
Code Couleur_Couleur_Code Fabrication_Num de Lot__

Exemples réels :
- C01_BLANC_NM15-01.00_S2023__
- C03_BEIGE CLAIR_NM05-03.02_S2023__
- C04_TAUPE_NM15-04.00_65370__
```

**Données matières gérées :**
- QR MP (identifiant unique)
- Code Commercial (C01, C02, C03, C04...)
- Code Couleur
- Couleur (nom complet)
- Code Fabrication MP (référence fournisseur)
- Numéro Métrique (NM05, NM12, NM15, NM20...)
- Num de Lot (traçabilité fournisseur)
- Stock Minimal (seuil alerte)

### ✅ Système multi-entrepôts

**Entrepôts gérés :**
- **E1** (Entrepôt 1)
- **E2** (Entrepôt 2)  
- **E3** (Entrepôt 3)
- **Usine** (atelier production)
- **Fabrication** (en cours de fabrication)
- **Sous-traitants** (Chokri Haddad, Wajdi, Lotfi Tilouche, Dimatex)

**Types d'opérations de stock :**
1. Achat (réception fournisseur)
2. Vente (expédition client)
3. Transfert (déplacement entre entrepôts)
4. Préparation (préparation pour OF)
5. Fabrication (consommation en production)
6. Retour Fabrication (retour MP non utilisée)
7. Inventaire (comptage physique périodique)

### ✅ Calculs de stock en temps réel

**Logique implémentée :**
```
Stock Actuel (par entrepôt) = 
  Stock du dernier inventaire 
  + SOMME(Tous les mouvements après cet inventaire)
```

**Alertes automatiques :**
- ❌ RUPTURE USINE si Stock Usine = 0 ET stock entrepôts > 0
- ⚠️ TRANSFERT NÉCESSAIRE si Stock Usine < 100 kg ET stock entrepôts > 0
- 🚨 URGENT - Rupture si Stock Final = 0 ET Stock Minimal > 0
- ⚠️ À commander si Stock Final < Stock Minimal

### ✅ Système de Sélecteurs (S01-S08)

**Concept unique de La Plume Artisanale :**
- **8 positions de fils** sur le métier à tisser (S01 à S08)
- Chaque sélecteur peut contenir un fil différent (couleur, métrique)
- Le BOM définit la consommation de chaque sélecteur
- Traçabilité complète : quel QR MP sur quel sélecteur

**Données par sélecteur :**
- Code Sélecteur (issu de BaseArticle)
- Consommation théorique (kg, issu du BOM)
- Besoin calculé (Qté × Consommation)
- QR MP réel utilisé (scanné en production)
- Lot réel utilisé
- Couleur réelle utilisée
- Poids réellement consommé

### ✅ États de préparation MP

**Logique à 3 états par OF :**

**Pour chaque OF, vérification globale S01-S08 :**
1. ✅ **Préparé** : Tous les sélecteurs nécessaires ont Poids Consommé ≥ Besoin
2. ⚠️ **Partiel** : Au moins 1 sélecteur préparé mais pas tous
3. ❌ **Non Préparé** : Aucun sélecteur préparé

**Calcul par sélecteur :**
```
Pour S01 à S08 :
  Préparé = SOMME(Poids préparés pour ce sélecteur et cet OF)
  Besoin = Qté Composant × Conso Sélecteur (du BOM)
  
  SI Préparé >= Besoin → Sélecteur OK
  SINON SI Préparé > 0 → Sélecteur Partiel
  SINON → Sélecteur Non Préparé
```

---

## 1.5 GESTION DE PRODUCTION

### ✅ Module TISSAGE

**Données de tissage gérées :**
- Num OF / Num Sous OF
- Num Machine (M2301-M2312, M2401-M2405, etc.)
- Tisseur (Ridha, Badii, Skander, Dhaker, Samir, Abdel Raouf, Med Amine, Bayrem)
- Date départ fabrication
- Date fin fabrication
- QTE Produire (pièces à tisser)
- QTE Fabriquer (pièces réellement tissées)

**États tissage :**
- ❌ Non Démarré (aucune date de départ)
- 🔄 En cours (date départ mais pas de date fin)
- ✅ Terminé (date fin ET QTE Fabriquer = QTE Produire)
- ⚠️ Terminé Qte Manquante (date fin mais QTE Fabriquer < QTE Produire)

**Récupération automatique :**
- Dernier état tissage par OF (tri par date descendant)
- Intégration Num Machine manuel si saisi dans Commandes
- Recalcul automatique si données changent

### ✅ Caractéristiques machines

**Données par machine (23+ machines) :**
- Numéro machine (M2301, M2302, M2401...)
- Type (HTV, GTN, Jacquard, Éponge)
- Système (Cadre, Jacquard, Éponge)
- État (En fonction, Hors service, En cours de mise en fonction)
- Unité (Usine, Sous-traitant)
- Laize machine (largeur max tissage)
- Laize actuelle (largeur configuration actuelle)
- Longueur peigne
- Nombre de fils par cm
- Sélecteurs installés (2 à 8)
- Type de programme (Programme, Carton)
- **Vitesse (duites/minute)** - ESSENTIEL pour calculs
- **Facteur compteur** - ESSENTIEL pour calculs
- Unité compteur (Mètre ou Rapport)
- Parc (Parc01, Parc02, Parc03)

### ✅ Calculs automatiques production

**1. Métrage fil de chaîne :**
```
Métrage Fil Chaîne (m) = (Longueur Tissu × Qté Composant) / 100

Exemple :
  Longueur : 240 cm
  Qté : 100 pièces
  → (240 × 100) / 100 = 240 mètres
```

**2. Nombre de duites total :**
```
Nb Duites Total Production = Duite par CM × Longueur Tissu × Qté Composant

Exemple :
  Duite/CM : 10,8
  Longueur : 240 cm
  Qté : 100 pièces
  → 10,8 × 240 × 100 = 259 200 duites
```

**3. Temps de production théorique :**
```
Temps Production (heures) = Nb Duites Total / (Vitesse Machine × 60)

Exemple :
  Duites : 259 200
  Vitesse : 220 duites/min
  → 259 200 / (220 × 60) = 19,6 heures
```

**4. Compteur machine :**
```
Selon l'unité compteur :
  
  SI Unité = "Mètre" :
    Compteur = (Longueur Tissu / 100) × Qté × Facteur Compteur
    
  SI Unité = "Rapport" :
    Compteur = Qté × Facteur Compteur
```

### ✅ Module COUPE

**Données de coupe gérées :**
- Num OF
- Coupeur (Walid, Abdelkader, Farouk, Amine)
- Date coupe
- QTE Deuxieme Fab (quantité coupée)

**Logique cumulative implémentée :**
```
QTE Fabriquer Coupe = SOMME(Toutes les QTE Deuxieme Fab pour cet OF)

Permet de gérer :
- Coupes multiples sur le même OF
- Historique complet des coupes
- Calcul du reste à fabriquer
```

**États coupe :**
- ❌ Non Démarré (aucune ligne de coupe)
- 🔄 En cours (QTE Fabriquer Coupe < A Fabriquer)
- ✅ Terminé (QTE Fabriquer Coupe = A Fabriquer)
- ⚠️ Terminé Qte Manquante (possible si ajustements)

### ✅ Module QUALITÉ (Contrôle final)

**Données qualité gérées :**
- Num OF
- Contrôleur (Ahmed Amine, Med Elyes, Omar, Ali)
- Date contrôle
- Qte Deu Ext (quantité validée après contrôle)
- Ourlet (type de finition appliqué)

**Usage :**
- Validation qualité avant expédition
- Traçabilité des contrôles
- Dernier état par OF

---

## 1.6 CALCUL DU RESTE À FABRIQUER

### ✅ Formule implémentée

```
Reste A Fabriquer = A Fabriquer - QTE Fabriquer Coupe

Où :
  A Fabriquer = Quantité initialement à fabriquer
  QTE Fabriquer Coupe = Cumul historique de toutes les coupes
```

**Avantages :**
- Suivi temps réel de l'avancement
- Gestion des productions multiples sur un même OF
- Visibilité sur ce qui reste à produire

---

## 1.7 APPLICATION WEB DE GESTION

### ✅ Fonctionnalités de l'application web

**URL :** https://fabrication.laplume-artisanale.tn

**Modules implémentés :**

#### 1. Dashboard (Tableau de bord)
- Vue d'ensemble production
- Indicateurs clés
- États des OF

#### 2. Ordres de Fabrication
- Liste complète des OF
- Filtrage par état
- Détails OF avec composants

#### 3. Matières Premières
- Catalogue complet MP
- Génération étiquettes avec QR codes
- États de stock par entrepôt
- Alertes stock

#### 4. Suivi Production
- **Tissage** : Attribution machines, suivi tisseurs
- **Coupe** : Enregistrement coupes
- **Qualité** : Contrôles finaux

#### 5. Catalogue Fils
- Génération catalogues échantillons avec QR codes
- Format impression professionnel
- Codes couleur normalisés

#### 6. Étiquettes / Impression
- Génération étiquettes produits
- Étiquettes MP avec QR codes
- Formats personnalisables

**Intégration :**
- Connexion Azure AD (authentification Microsoft)
- Chargement données depuis SharePoint Excel
- Hébergement OVH
- SSL activé

---

## 1.8 SYSTÈME DE SCAN MOBILE (KIOSK ENTREPÔT)

### ✅ Application tablette

**Fonctionnalités :**
- Scan QR codes matières premières
- Scan QR codes OF/Sous-OF
- Enregistrement mouvement temps réel
- Mode kiosk (dédié à cette fonction)
- Synchronisation automatique avec SharePoint

**Usage :**
- Préparation matières pour OF
- Enregistrement consommation production
- Retours matières
- Transferts entre entrepôts

**Outil utilisé :**
- Scan-IT to Office
- Intégration directe SharePoint
- Pas de développement nécessaire

---

# PARTIE 2 : BESOINS ET AMÉLIORATIONS IDENTIFIÉS

## 2.1 DOSSIER DE FABRICATION AUTOMATISÉ

### 🎯 Besoin identifié

**Objectif :** Créer automatiquement un **dossier de fabrication complet** pour chaque OF, contenant toutes les informations nécessaires au circuit de production.

**Contenu du dossier :**

#### Page 1 : En-tête OF
- N° OF Principal + Suffixe
- Client
- Modèle
- Dimensions
- Qualité/Type
- Quantité totale
- Date lancement
- Date livraison prévue
- Machine assignée (si connue)

#### Page 2 : Préparation Matières Premières
**Pour le magasinier MP :**
- Liste des sélecteurs S01-S08 nécessaires
- Pour chaque sélecteur :
  - Code fil (référence)
  - Couleur
  - Quantité nécessaire (kg)
  - Emplacement stock
  - QR code à scanner ⬜ (case à cocher après scan)
  
**Workflow :**
1. Magasinier scanne QR MP → case cochée automatiquement
2. État "Préparé" mis à jour temps réel
3. Validation globale quand tous sélecteurs scannés

#### Page 3 : Fiche Tissage
**Pour le tisseur :**
- Num Sous OF (QR code pour scan)
- Paramètres tissage :
  - Largeur tissu
  - Longueur tissu
  - Duites/CM
  - Programme/Carton à utiliser
- Sélecteurs installés (S01-S08)
- Compteur attendu
- Zones de saisie :
  - ⬜ Départ fabrication (date/heure + scan QR OF)
  - ⬜ Fin fabrication (date/heure + scan QR OF)
  - ⬜ Quantité produite
  - ⬜ Observations/défauts

#### Page 4 : Fiche Coupe
**Pour le coupeur :**
- Num OF (QR code)
- Quantité à couper
- Dimensions finales
- Gabarit de coupe
- Zones de saisie :
  - ⬜ Date coupe (+ scan QR OF)
  - ⬜ Quantité coupée
  - ⬜ Chutes/pertes
  - ⬜ Observations

#### Page 5 : Fiche Contrôle Qualité
**Pour le contrôleur :**
- Num OF (QR code)
- Critères contrôle :
  - ⬜ Dimensions conformes
  - ⬜ Couleurs conformes
  - ⬜ Absence défauts tissage
  - ⬜ Finition correcte
  - ⬜ Emballage conforme
- Zones de saisie :
  - ⬜ Date contrôle (+ scan QR OF)
  - ⬜ Quantité validée
  - ⬜ Quantité rebutée
  - ⬜ Nature défauts
  - ⬜ Validation finale

### 💡 Amélioration proposée

**Génération automatique depuis Base_Commandes :**
1. Sélection OF dans interface
2. Récupération automatique toutes données (BOM, MP, etc.)
3. Génération PDF dossier complet
4. Impression en 1 clic
5. QR codes intégrés pour scan à chaque étape

**Bénéfices :**
- ✅ Zéro saisie manuelle
- ✅ Traçabilité complète par scan
- ✅ Mise à jour temps réel des états
- ✅ Historique complet des opérations
- ✅ Réduction erreurs

---

## 2.2 PLANIFICATION PRODUCTION (GANTT)

### 🎯 Besoin identifié

**Objectif :** Disposer d'une **vue Gantt** de la planification pour optimiser l'utilisation des machines et respecter les dates de livraison.

**Fonctionnalités nécessaires :**

#### Paramètres de planification
- Date début production (calculée ou manuelle)
- Machine assignée
- Temps production estimé (calculé automatiquement)
- Temps setup machine
- Temps de séchage/refroidissement si applicable
- Dépendances entre tâches

#### Calculs automatiques
```
Date Fin Prévue = Date Début + Temps Production + Temps Setup

Temps Production = Nb Duites Total / (Vitesse Machine × 60)
```

#### Vue Gantt
- Ligne par OF
- Barre représentant durée production
- Couleur selon état (Planifié/En cours/Terminé)
- Affichage machine assignée
- Dépendances visuelles
- Date livraison client (milestone)

#### Optimisation
- Détection conflits machines (2 OF sur même machine en même temps)
- Suggestions réaffectation machines
- Calcul charge machines (% utilisation)
- Alerte retards prévisibles

### 💡 Amélioration proposée

**Intégration dans l'application web :**
- Module "Planning" avec vue Gantt interactive
- Drag & drop pour réaffecter machines/dates
- Filtrage par machine, par date, par client
- Export PDF planning hebdomadaire/mensuel
- Synchronisation automatique avec Base_Commandes

---

## 2.3 ALERTES ET NOTIFICATIONS

### 🎯 Besoin identifié

**Objectif :** Système d'**alertes proactives** pour prévenir les problèmes avant qu'ils n'impactent la production.

**Types d'alertes à implémenter :**

#### Alertes Matières Premières
- 🚨 **Critique** : Stock = 0 ET OF en attente nécessitant cette MP
- ⚠️ **Attention** : Stock < Stock Minimal
- ⚠️ **Transfert** : Stock Usine < 100 kg ET stock entrepôts > 0
- 📊 **Info** : Inventaire non fait depuis X jours

#### Alertes Production
- 🚨 **Retard** : Date Fin Prévue < Date Livraison - X jours
- ⚠️ **Blocage** : OF "En cours" sans mouvement depuis X jours
- 📊 **Info** : OF prêt à démarrer (MP préparées)

#### Alertes Qualité
- 🚨 **Défaut** : Taux de rebut > X% sur un OF
- ⚠️ **Contrôle** : OF coupé mais pas contrôlé depuis X jours

#### Alertes Machines
- 🚨 **Panne** : Machine en panne impactant un OF planifié
- 📊 **Maintenance** : Maintenance préventive à planifier

### 💡 Amélioration proposée

**Système de notifications multi-canal :**
- Notifications dans l'application web (badge rouge)
- Emails automatiques aux responsables
- Intégration Microsoft Teams (si souhaité)
- Dashboard dédié "Alertes & Actions"
- Historique des alertes et actions prises

---

## 2.4 AMÉLIORATION TRAÇABILITÉ

### 🎯 Besoin identifié

**Objectif :** Renforcer la **traçabilité complète** du fil à tisser au produit fini.

**Fonctionnalités à ajouter :**

#### Traçabilité amont (MP → Produit)
- Lien MP consommée → Num Sous OF → Produit Fini
- Requête type : "Quels produits finis contiennent le lot 65370 ?"
- Possibilité de rappel ciblé si défaut MP

#### Traçabilité aval (Produit → MP)
- Lien Produit Fini → Num Sous OF → MP utilisées
- Requête type : "Quelles MP composent le produit fini ref XYZ ?"
- Certificats de traçabilité automatiques

#### Traçabilité opérateurs
- Qui a tissé ? Qui a coupé ? Qui a contrôlé ?
- Date et heure précises de chaque opération
- Scan badge opérateur lors des scans QR OF

#### Traçabilité machine
- Quelle machine a tissé chaque pièce ?
- Historique machine (quels OF produits ?)
- Corrélation défauts / machines

### 💡 Amélioration proposée

**Module "Traçabilité Avancée" :**
- Interface de recherche multi-critères
- Graphe de traçabilité visuel (MP → Opérations → Produit)
- Export rapports traçabilité (pour audits, certifications)
- API pour intégration futurs systèmes (ERP externe, etc.)

---

## 2.5 GESTION SOUS-TRAITANCE

### 🎯 Besoin identifié

**Objectif :** Mieux gérer les **OF en sous-traitance** (Chokri Haddad, Wajdi, Lotfi Tilouche, Dimatex).

**Fonctionnalités à développer :**

#### Envoi en sous-traitance
- Sélection OF à sous-traiter
- Choix sous-traitant
- Génération bon de sortie MP
- Génération dossier fabrication sous-traitant
- Enregistrement transfert MP vers sous-traitant

#### Suivi sous-traitance
- État avancement chez sous-traitant
- Date prévue retour
- Quantité en cours chez sous-traitant
- Alertes si retard

#### Réception retour sous-traitance
- Scan réception produits finis
- Contrôle qualité réception
- Retour MP non utilisées
- Mise à jour stocks

#### Facturation sous-traitance
- Suivi quantités facturables
- Tarifs par sous-traitant
- Génération bordereaux

### 💡 Amélioration proposée

**Module "Sous-Traitance" dédié :**
- Workflow complet envoi/suivi/réception
- Tableau de bord sous-traitance (en cours, retards)
- Historique par sous-traitant (performance, qualité)
- Intégration comptabilité (si ERP complet)

---

## 2.6 INDICATEURS DE PERFORMANCE (KPI)

### 🎯 Besoin identifié

**Objectif :** Disposer d'**indicateurs clés** pour piloter l'activité.

**KPI à implémenter :**

#### KPI Production
- Taux de respect délais (%)
- Taux d'utilisation machines (%)
- Temps moyen par OF
- Productivité par tisseur (pièces/jour)
- Taux de rebut (%)

#### KPI Qualité
- Taux de défauts par type
- Taux de non-conformités
- Réclamations clients

#### KPI Stock
- Taux de rotation stock MP
- Nombre de ruptures
- Valeur stock immobilisé

#### KPI Financiers
- Coût production par OF
- Marge brute par produit
- Coût MP consommées vs budget

### 💡 Amélioration proposée

**Dashboard KPI interactif :**
- Vue synthétique (graphiques, jauges)
- Filtres par période, par machine, par produit
- Évolution temporelle (courbes)
- Export Excel/PDF pour direction
- Comparaison périodes (mois M vs M-1)

---

## 2.7 OPTIMISATION CALCULS POWER QUERY

### 🎯 Besoin identifié

**Objectif :** Améliorer les **performances** du système Power Query actuel.

**Points d'amélioration :**

#### Optimisations déjà implémentées ✅
- Filtrage immédiat dès le chargement
- Sélection colonnes nécessaires uniquement
- Typage après filtrage (pas avant)
- Utilisation Table.Buffer() sur groupements coûteux
- Éviter les itérations inutiles

#### Optimisations supplémentaires à faire
- **Indexation des jointures** : Ajouter index sur colonnes de jointure
- **Requêtes de référence** : Référencer plutôt que dupliquer
- **Folding** : S'assurer que le Query Folding fonctionne (push vers source)
- **Parallélisation** : Activer calculs parallèles dans options Excel
- **Mise en cache** : Stratégie de refresh partiel (pas tout à chaque fois)

### 💡 Amélioration proposée

**Audit et refactoring Power Query :**
- Analyse performances actuelles (temps refresh)
- Identification goulots d'étranglement
- Refactoring requêtes lentes
- Documentation bonnes pratiques
- Formation équipe sur maintenance

---

# PARTIE 3 : PLAN DE PARAMÉTRAGE STRUCTURÉ

## 3.1 PRÉPARATION DES DONNÉES DE BASE

### ✅ Étape 1 : Validation structure fichiers Excel

**Fichiers à vérifier :**

#### 1. Fichier Commandes
📁 Localisation : SharePoint / Fabrication / Commandes
📋 Tables : Base_Commandes_2025_2026, Base_Commandes_2024_2025

**Colonnes requises :**
- N° OF ou OF
- Code Commercial ou CODE FIN
- Référence
- Quantité ou Qte
- Reserve
- Statut
- Date Livraison
- Priorité
- Client
- Modèle
- Dimensions (code à convertir)
- Type de Finition
- Nombre de couleur

**Actions :**
- [ ] Vérifier cohérence noms colonnes
- [ ] Vérifier formats (dates, nombres)
- [ ] Nettoyer doublons éventuels
- [ ] Documenter conventions nommage

#### 2. Fichier BaseArticle
📁 Localisation : SharePoint / Fabrication / BaseArticle ou Catalogue

**Colonnes requises :**
- CODE FIN (ou Code Commercial)
- Ref Fabrication
- Code Selecteur 01 à Code Selecteur 08 ⚠️ CRITIQUE

**Actions :**
- [ ] Vérifier que TOUS les articles ont Ref Fabrication
- [ ] Vérifier codes sélecteurs renseignés (S01-S08)
- [ ] Compléter éventuelles données manquantes
- [ ] Standardiser format codes sélecteurs

#### 3. Fichier Paramétrages (BOM)
📁 Localisation : SharePoint / Fabrication / Paramétrages.xlsx

**Tables requises :**
- **Paramétrage_Master** (produits finis)
- **Paramétrage_Composants** (composants détaillés)

**Colonnes Master :**
- Code paramétrage
- Produit
- Modèle
- Code Dimensions
- Type de Finition
- Nombre de couleur
- Type de Fabrication (Unique/Composer)

**Colonnes Composants :**
- Code paramétrage (clé étrangère)
- ID Composant (Unique, C01, C02...)
- Description
- Qté par Unité ⚠️ ESSENTIEL
- Largeur Tissage
- Longueur Tissage
- Duite par CM
- Nombre Duites Total
- Consommation Selecteur 01 à 08 (kg)

**Actions :**
- [ ] Compléter tous les BOM manquants
- [ ] Vérifier cohérence "Qté par Unité" (produits composés)
- [ ] Valider consommations S01-S08
- [ ] Tester fusion BOM avec quelques commandes

#### 4. Fichier Données Collecte (Mouvements MP)
📁 Localisation : SharePoint / Saisie / Donnée collecte.xlsx

**Table : mouvementmp**

**Colonnes requises :**
- QR MP
- Date
- Type D'opération
- Depart (entrepôt source)
- Destination (entrepôt cible)
- Poids (kg)
- Mouvement (kg, peut être négatif)
- Code Couleur
- Code Fabrication MP
- Num de Lot
- Num OF (si applicable)
- Sélecteur (S01-S08, si applicable)

**Actions :**
- [ ] Nettoyer données anciennes si nécessaire
- [ ] Vérifier cohérence entrepôts (E1, E2, E3, Usine, Fabrication)
- [ ] Valider format QR MP
- [ ] Compléter derniers inventaires

#### 5. Fichier Matière Première (Catalogue)
📁 Localisation : SharePoint / Matière Première / Suivis Matière Première 2025-2026.xlsx

**Table : Matiere_premiere**

**Colonnes requises :**
- QR MP
- Numero Métrique
- Code Couleur
- Couleur (nom)
- Code Fabrication MP
- Num de Lot
- Stock Minimal (seuil alerte)
- Couleur Commercial (famille)

**Actions :**
- [ ] Compléter Stock Minimal pour tous articles
- [ ] Vérifier cohérence QR MP avec mouvements
- [ ] Nettoyer doublons
- [ ] Compléter infos manquantes (métrique, couleur...)

#### 6. Fichiers Production
📁 Localisation : SharePoint / Saisie / Donnée collecte.xlsx

**Tables : tissage, coupe, qualité**

**Colonnes requises Tissage :**
- Num OF
- Num Sous OF
- Num Machine
- Tisseur
- Date Départ
- Date Fin
- QTE Produire
- QTE Fabriquer

**Colonnes requises Coupe :**
- Num OF
- Coupeur
- Date
- QTE Deuxieme Fab

**Colonnes requises Qualité :**
- Num OF
- Contrôleur
- Date
- Qte Deu Ext
- Ourlet

**Actions :**
- [ ] Vérifier cohérence Num OF avec Commandes
- [ ] Compléter opérateurs manquants
- [ ] Nettoyer dates invalides

#### 7. Fichier Caractéristiques Machines
📁 Localisation : À créer si n'existe pas

**Colonnes requises :**
- Numéro Machine (M2301, M2302...)
- Type Machine
- Système (Cadre, Jacquard...)
- État (En fonction, Hors service...)
- Unité (Usine, Sous-traitant)
- Laize Machine
- Vitesse (duites/minute) ⚠️ CRITIQUE pour calculs
- Facteur Compteur ⚠️ CRITIQUE pour calculs
- Unité Compteur (Mètre ou Rapport)
- Parc

**Actions :**
- [ ] Centraliser infos machines dispersées
- [ ] Valider vitesses réelles (mesurer si besoin)
- [ ] Documenter facteurs compteur
- [ ] Tenir à jour l'état des machines

---

### ✅ Étape 2 : Configuration Power Query

**Tâche :** Créer/Vérifier les requêtes Power Query dans Excel

#### Requêtes de base (sources)

1. **Source_Commandes_2025_2026**
   - [ ] Connexion SharePoint OK
   - [ ] Colonnes reconnues
   - [ ] Typage correct

2. **Source_Commandes_2024_2025**
   - [ ] Connexion SharePoint OK
   - [ ] Même structure que 2025-2026

3. **Source_Catalogue**
   - [ ] Connexion OK
   - [ ] Champs Ref Fabrication + Codes Sélecteurs présents

4. **Source_BOM_Master**
   - [ ] Connexion Paramétrages.xlsx OK
   - [ ] Table détectée

5. **Source_BOM_Composants**
   - [ ] Connexion Paramétrages.xlsx OK
   - [ ] Table détectée

6. **Source_MouvementMP**
   - [ ] Connexion Donnée collecte.xlsx OK
   - [ ] Tous types opérations présents

7. **Source_Matiere_Premiere**
   - [ ] Connexion OK
   - [ ] Stock Minimal renseigné

8. **Source_Tissage**
   - [ ] Connexion OK
   - [ ] Dates valides

9. **Source_Coupe**
   - [ ] Connexion OK

10. **Source_Qualite**
    - [ ] Connexion OK

11. **Source_Machines**
    - [ ] Connexion OK
    - [ ] Vitesses et Facteurs Compteur OK

#### Requêtes de transformation

12. **Union_Commandes**
    - [ ] Combine 2025-2026 + 2024-2025
    - [ ] Colonnes harmonisées
    - [ ] Filtrage statuts si souhaité

13. **Fusion_Commandes_BaseArticle**
    - [ ] Jointure sur CODE FIN
    - [ ] Récupération Ref Fabrication + Codes S01-S08
    - [ ] Gestion articles non trouvés

14. **Fusion_BOM**
    - [ ] Jointure Master + Composants sur Code paramétrage
    - [ ] Jointure avec Commandes sur Modèle + Dimensions + Finition + Nb couleur
    - [ ] Gestion produits Composer (suffixes /1, /2, /3)

15. **Calculs_Production**
    - [ ] Métrage Fil Chaîne
    - [ ] Nb Duites Total
    - [ ] Besoins S01-S08 (kg)
    - [ ] Qté Composant à Fabriquer

16. **Traçabilité_MP**
    - [ ] Jointure MouvementMP avec Commandes (sur Num OF)
    - [ ] Filtrage Type Opération = Préparation ou Fabrication
    - [ ] Pivot sur Sélecteurs S01-S08
    - [ ] Récupération QR MP Réel, Lot, Poids Consommé

17. **États_Préparation_MP**
    - [ ] Comparaison Poids Consommé vs Besoin (S01-S08)
    - [ ] Calcul état global : Préparé / Partiel / Non Préparé

18. **Stocks_MP**
    - [ ] Calcul stock par entrepôt (E1, E2, E3, Usine, Fabrication)
    - [ ] Prise en compte derniers inventaires
    - [ ] Alertes Stock < Minimal

19. **Fusion_Tissage**
    - [ ] Récupération dernier état tissage par OF
    - [ ] Calcul état : Non Démarré / En cours / Terminé / Terminé Qte Manquante

20. **Fusion_Coupe**
    - [ ] Groupement par OF, somme QTE Deuxieme Fab
    - [ ] Calcul Reste A Fabriquer
    - [ ] Calcul état coupe

21. **Fusion_Qualite**
    - [ ] Récupération dernier contrôle par OF

22. **Requête_Finale_Base_Commandes**
    - [ ] Intégration toutes les fusions
    - [ ] Colonnes organisées logiquement
    - [ ] Nommage clair et cohérent
    - [ ] Commentaires dans le code

#### Tests et validation

- [ ] Tester avec petit échantillon (10 OF)
- [ ] Vérifier calculs manuellement (1-2 OF)
- [ ] Valider cohérence états
- [ ] Mesurer temps refresh (acceptable ?)
- [ ] Documenter éventuels problèmes

---

### ✅ Étape 3 : Création des tableaux de bord Excel

**Tâche :** Exploiter les requêtes Power Query dans des tableaux de bord

#### Tableau de bord 1 : Vue Commandes Production

**Objectif :** Vue d'ensemble des OF avec états

**Données source :** Requête_Finale_Base_Commandes

**Colonnes à afficher :**
- Num OF (avec suffixe si applicable)
- Client
- Modèle
- Dimensions
- Qté Commandé
- Reste A Fabriquer
- Etat Préparation MP (⚠️ mise en forme conditionnelle)
- Etat Tissage (⚠️ mise en forme conditionnelle)
- Etat Coupe (⚠️ mise en forme conditionnelle)
- Date Livraison
- Priorité

**Filtres dynamiques :**
- [ ] Segments : État, Modèle, Client, Priorité
- [ ] Recherche Num OF
- [ ] Plage dates livraison

**Mise en forme :**
- [ ] Mise en forme conditionnelle états (rouge/orange/vert)
- [ ] Alertes retards (fond rouge si Date Livraison proche)
- [ ] Figer volets
- [ ] Grouper par statut

**Actions :**
- [ ] Créer tableau croisé dynamique ou table Excel
- [ ] Ajouter segments
- [ ] Configurer mise en forme
- [ ] Ajouter bouton refresh données

#### Tableau de bord 2 : Stocks Matières Premières

**Objectif :** Suivi stocks temps réel + alertes

**Données source :** Requête Stocks_MP fusionnée avec Matiere_Premiere

**Colonnes à afficher :**
- QR MP
- Numero Métrique
- Code Couleur
- Couleur
- Code Fabrication MP
- Num de Lot
- Stock E1
- Stock E2
- Stock E3
- Stock Usine
- Stock Fabrication (en cours)
- Stock Total
- Stock Minimal
- Écart (Total - Minimal)
- Demande Transfert Usine (⚠️)
- Demande Achat (⚠️)
- Statut Achat (⚠️ mise en forme)

**Filtres :**
- [ ] Segment : Métrique, Couleur
- [ ] Filtre : Articles en rupture
- [ ] Filtre : Articles à commander

**Graphiques :**
- [ ] Répartition stock par entrepôt (camembert)
- [ ] Top 10 articles en rupture
- [ ] Évolution stock dans le temps (si historique)

**Actions :**
- [ ] Créer tableau
- [ ] Ajouter mise en forme conditionnelle (rouge si rupture)
- [ ] Ajouter graphiques
- [ ] Bouton export liste achat

#### Tableau de bord 3 : Production Machines

**Objectif :** Suivi production par machine

**Données source :** Fusion Commandes + Tissage + Machines

**Vue 1 : Par OF**
- Num OF
- Machine
- Tisseur
- Date Départ
- Date Fin Prévue (calculée)
- État Tissage

**Vue 2 : Par Machine**
- Machine
- Nb OF en cours
- Nb OF terminés (période)
- Taux utilisation (%)
- Prochains OF planifiés

**Graphiques :**
- [ ] Diagramme Gantt (si possible Excel, sinon app web)
- [ ] Charge par machine (barres)
- [ ] Performance tisseurs (pièces/jour)

**Actions :**
- [ ] Créer vues
- [ ] Ajouter calculs performance
- [ ] Graphiques de synthèse

#### Tableau de bord 4 : Suivi Production Globale

**Objectif :** KPI de production

**Indicateurs :**
- Nb OF en cours
- Nb OF terminés (mois)
- Taux respect délais (%)
- Quantité produite (pièces)
- Taux utilisation machines moyen (%)
- Stock MP valorisé

**Graphiques :**
- [ ] Évolution production mensuelle
- [ ] Répartition OF par état (camembert)
- [ ] Délais moyens par étape

**Actions :**
- [ ] Créer mesures DAX (si Power Pivot)
- [ ] Créer graphiques
- [ ] Page récapitulative direction

---

### ✅ Étape 4 : Configuration Application Web

**Tâche :** Paramétrer l'application web de gestion

#### Configuration Azure AD

**Actions :**
- [ ] Créer App Registration dans Azure AD
- [ ] Noter Client ID et Tenant ID
- [ ] Configurer Redirect URI : https://fabrication.laplume-artisanale.tn
- [ ] Activer authentification Microsoft
- [ ] Tester connexion

#### Configuration SharePoint

**Actions :**
- [ ] Vérifier permissions application sur SharePoint
- [ ] Configurer URLs fichiers Excel dans app
- [ ] Tester chargement données depuis app
- [ ] Vérifier refresh temps réel

#### Modules à activer/configurer

1. **Module Ordres de Fabrication**
   - [ ] Affichage liste OF
   - [ ] Détails OF (composants, MP, états)
   - [ ] Filtres et recherche
   - [ ] Génération dossier fabrication PDF

2. **Module Matières Premières**
   - [ ] Catalogue complet
   - [ ] Génération étiquettes QR
   - [ ] États stocks
   - [ ] Alertes

3. **Module Production**
   - [ ] Saisie données tissage
   - [ ] Saisie données coupe
   - [ ] Saisie contrôle qualité
   - [ ] Association machines/tisseurs

4. **Module Catalogue Fils**
   - [ ] Génération catalogues échantillons
   - [ ] Impression format A4
   - [ ] QR codes intégrés

5. **Module Planning** (à développer)
   - [ ] Vue Gantt
   - [ ] Attribution machines
   - [ ] Calculs dates prévisionnelles

**Actions :**
- [ ] Tester chaque module
- [ ] Corriger bugs éventuels
- [ ] Former utilisateurs
- [ ] Créer guides utilisateur

#### Hébergement et sécurité

**Actions :**
- [ ] Vérifier SSL actif (Let's Encrypt)
- [ ] Configurer sauvegardes
- [ ] Tester performances
- [ ] Définir politique mots de passe
- [ ] Logs d'accès activés

---

### ✅ Étape 5 : Configuration Scan Mobile (Kiosk)

**Tâche :** Déployer solution scan tablette entrepôt

#### Installation Scan-IT to Office

**Actions :**
- [ ] Installer app sur tablette(s)
- [ ] Configurer connexion SharePoint
- [ ] Définir cible : fichier Donnée collecte.xlsx, table mouvementmp

#### Configuration formulaires scan

**Formulaire 1 : Préparation MP pour OF**
- Scan QR MP → récupère Code Couleur, Code Fab, Lot
- Scan Num OF → récupère OF cible
- Sélection Sélecteur (S01-S08)
- Saisie Poids
- → Insertion ligne dans mouvementmp (Type = Préparation)

**Formulaire 2 : Consommation Production**
- Scan Num Sous OF
- Scan QR MP
- Sélecteur
- Poids consommé
- → Insertion (Type = Fabrication)

**Formulaire 3 : Retour MP**
- Scan Num OF
- Scan QR MP
- Poids retourné
- → Insertion (Type = Retour Fabrication)

**Formulaire 4 : Transfert MP**
- Scan QR MP
- Sélection Entrepôt Départ
- Sélection Entrepôt Destination
- Poids
- → Insertion (Type = Transfert)

**Actions :**
- [ ] Créer les 4 formulaires
- [ ] Tester chaque formulaire
- [ ] Valider insertions dans Excel
- [ ] Vérifier refresh Power Query automatique
- [ ] Former magasiniers/tisseurs

#### Mode Kiosk

**Actions :**
- [ ] Configurer tablette en mode kiosk (seule app visible)
- [ ] Désactiver notifications/distractions
- [ ] Écran toujours allumé (ou timeout long)
- [ ] Support tablette fixe ou mobile selon usage

---

### ✅ Étape 6 : Génération Dossiers de Fabrication

**Tâche :** Automatiser création dossiers fabrication PDF

#### Développement du générateur

**Option A : Via Application Web (recommandé)**

**Actions :**
- [ ] Créer page "Générer Dossier Fabrication"
- [ ] Sélection OF depuis liste
- [ ] Récupération automatique toutes données (BOM, MP, etc.)
- [ ] Template HTML du dossier (5 pages)
- [ ] Génération PDF (bibliothèque jsPDF ou html2pdf)
- [ ] QR codes intégrés (bibliothèque qrcode.js)
- [ ] Téléchargement PDF en 1 clic

**Option B : Via Excel/VBA**

**Actions :**
- [ ] Créer template Word du dossier
- [ ] Macro VBA récupération données depuis requêtes
- [ ] Remplissage automatique template
- [ ] Génération QR codes (add-in ou bibliothèque)
- [ ] Export PDF

**Choix recommandé : Option A (Web)** car :
- Plus moderne et maintenable
- Accessible de partout
- Pas besoin Office
- Intégration native app

#### Contenu du dossier (rappel)

**Page 1 : En-tête OF**
- [ ] Informations OF complètes
- [ ] QR code Num OF principal

**Page 2 : Préparation MP**
- [ ] Liste sélecteurs avec QR codes
- [ ] Cases à cocher (scan)
- [ ] Instructions magasinier

**Page 3 : Fiche Tissage**
- [ ] Paramètres tissage
- [ ] QR code Num Sous OF
- [ ] Zones de saisie

**Page 4 : Fiche Coupe**
- [ ] Instructions coupe
- [ ] QR code Num OF
- [ ] Zones de saisie

**Page 5 : Fiche Contrôle Qualité**
- [ ] Checklist contrôle
- [ ] QR code Num OF
- [ ] Zones validation

**Actions :**
- [ ] Designer templates
- [ ] Implémenter générateur
- [ ] Tester avec quelques OF
- [ ] Valider avec utilisateurs
- [ ] Ajuster si besoin

---

### ✅ Étape 7 : Mise en Place Planning Gantt

**Tâche :** Créer vue planning production

#### Développement module Planning

**Option A : Bibliothèque JavaScript (recommandé)**

**Bibliothèques possibles :**
- DHTMLX Gantt (version gratuite)
- Frappe Gantt (open source)
- Google Charts Gantt

**Actions :**
- [ ] Choisir bibliothèque
- [ ] Intégrer dans application web
- [ ] Récupérer données OF depuis SharePoint
- [ ] Calculer dates début/fin prévisionnelles
- [ ] Affichage barres Gantt
- [ ] Couleurs selon état
- [ ] Filtres (machine, période, client)
- [ ] Drag & drop pour réaffecter (si souhaité)

**Option B : Excel (moins puissant)**

**Actions :**
- [ ] Créer diagramme Gantt Excel (barres conditionnelles)
- [ ] Mise à jour manuelle ou via macro
- [ ] Moins interactif mais fonctionnel

**Choix recommandé : Option A** pour interactivité

#### Calculs dates prévisionnelles

**Formules à implémenter :**

```javascript
Date Fin Prévue = Date Début + Temps Production + Temps Setup

Temps Production (heures) = Nb Duites Total / (Vitesse Machine × 60)

Temps Setup = 30 minutes (configurable par machine)
```

**Actions :**
- [ ] Implémenter calculs
- [ ] Permettre ajustement manuel Date Début
- [ ] Alertes si Date Fin > Date Livraison
- [ ] Suggestions réaffectation machine si conflit

#### Optimisation planning

**Fonctionnalités avancées (phase 2) :**
- [ ] Algorithme optimisation automatique
- [ ] Détection conflits machines
- [ ] Suggestions réordonnancement
- [ ] Calcul charge machines (%)
- [ ] Prévisions délais réalistes

---

### ✅ Étape 8 : Implémentation Système d'Alertes

**Tâche :** Créer système de notifications proactives

#### Configuration règles d'alertes

**Alertes MP :**

1. **Stock = 0**
   - Condition : Stock Total = 0 ET Stock Minimal > 0
   - Niveau : 🚨 Critique
   - Action : Email responsable achats + notification app

2. **Stock < Minimal**
   - Condition : Stock Total < Stock Minimal
   - Niveau : ⚠️ Attention
   - Action : Notification app

3. **Transfert Usine nécessaire**
   - Condition : Stock Usine < 100 kg ET (E1 + E2 + E3) > 0
   - Niveau : ⚠️ Attention
   - Action : Notification magasinier

**Alertes Production :**

1. **Retard prévisible**
   - Condition : Date Fin Prévue > Date Livraison - 7 jours
   - Niveau : 🚨 Critique
   - Action : Email responsable production

2. **OF bloqué**
   - Condition : État "En cours" ET aucun mouvement depuis 3 jours
   - Niveau : ⚠️ Attention
   - Action : Notification app

3. **OF prêt à démarrer**
   - Condition : Etat Préparation MP = "Préparé" ET Etat Tissage = "Non Démarré"
   - Niveau : 📊 Info
   - Action : Notification app

**Alertes Qualité :**

1. **Taux rebut élevé**
   - Condition : (Qte Rebut / Qte Produite) > 5%
   - Niveau : 🚨 Critique
   - Action : Email responsable qualité

**Actions :**
- [ ] Définir toutes les règles d'alerte
- [ ] Configurer seuils (modifiables)
- [ ] Définir destinataires par type alerte

#### Implémentation technique

**Option A : Depuis Application Web**

**Actions :**
- [ ] Créer script vérification alertes (exécuté périodiquement)
- [ ] Stockage état alertes (pour éviter doublons)
- [ ] Dashboard "Alertes en cours"
- [ ] Badge notification (nombre alertes non lues)
- [ ] Page détail alertes avec actions

**Option B : Power Automate (Microsoft Flow)**

**Actions :**
- [ ] Créer Flow : vérification quotidienne conditions
- [ ] Envoi emails automatiques si conditions remplies
- [ ] Notifications Teams (si souhaité)

**Choix recommandé : Combinaison A + B**
- App web pour alertes temps réel
- Power Automate pour emails automatiques

---

### ✅ Étape 9 : Renforcement Traçabilité

**Tâche :** Améliorer traçabilité complète

#### Base de données traçabilité

**Table à créer : Historique_Operations**

**Colonnes :**
- ID (auto-incrémenté)
- Date_Heure
- Type_Operation (Préparation, Tissage, Coupe, Qualité, Transfert)
- Num_OF
- Num_Sous_OF (si applicable)
- QR_MP (si applicable)
- Selecteur (si applicable)
- Operateur (nom/badge)
- Machine (si applicable)
- Quantite
- Unite
- Entrepot_Depart (si transfert)
- Entrepot_Destination (si transfert)
- Observations
- Statut (OK, Défaut, Rebut)

**Actions :**
- [ ] Créer table dans SharePoint ou SQL si disponible
- [ ] Modifier formulaires scan pour insérer dans cette table
- [ ] Insertion automatique depuis app web aussi

#### Module Traçabilité Avancée

**Requêtes à développer :**

1. **Traçabilité amont (MP → Produits)**
   - Input : QR MP ou Num Lot
   - Output : Liste Num Sous OF / OF contenant cette MP
   - Actions :
     - [ ] Interface recherche QR MP
     - [ ] Requête jointure MouvementMP + Commandes
     - [ ] Affichage arbre traçabilité

2. **Traçabilité aval (Produit → MP)**
   - Input : Num OF ou Num Sous OF
   - Output : Liste complète MP utilisées (S01-S08)
   - Actions :
     - [ ] Interface recherche OF
     - [ ] Récupération données MouvementMP filtrées
     - [ ] Affichage composition complète

3. **Historique opérations**
   - Input : Num OF ou QR MP ou Opérateur
   - Output : Chronologie complète opérations
   - Actions :
     - [ ] Requête sur Historique_Operations
     - [ ] Affichage ligne du temps
     - [ ] Export PDF "Certificat Traçabilité"

**Actions :**
- [ ] Créer page "Traçabilité" dans app web
- [ ] Implémenter les 3 types de requêtes
- [ ] Tester avec OF réels
- [ ] Créer template "Certificat Traçabilité" PDF

---

### ✅ Étape 10 : Module Sous-Traitance

**Tâche :** Gérer OF en sous-traitance

#### Workflow sous-traitance

**Étape 1 : Envoi en sous-traitance**

**Actions :**
- [ ] Page "Envoyer OF en sous-traitance"
- [ ] Sélection OF
- [ ] Choix sous-traitant (liste : Chokri Haddad, Wajdi, Lotfi Tilouche, Dimatex)
- [ ] Génération bon de sortie MP (PDF)
- [ ] Génération dossier fabrication sous-traitant
- [ ] Enregistrement transfert stock :
  - MP : Usine → Sous-traitant
  - État OF : "En sous-traitance"

**Étape 2 : Suivi sous-traitance**

**Actions :**
- [ ] Tableau "OF en sous-traitance"
- [ ] Colonnes : OF, Sous-traitant, Date envoi, Date retour prévue, Quantité
- [ ] Possibilité mise à jour avancement (%)
- [ ] Alertes si retard

**Étape 3 : Réception retour**

**Actions :**
- [ ] Page "Réception sous-traitance"
- [ ] Scan OF de retour
- [ ] Saisie quantité reçue
- [ ] Contrôle qualité réception
- [ ] Enregistrement retour stock :
  - Produits finis : Sous-traitant → Usine
  - MP non utilisées : Sous-traitant → E1 (ou Usine)
- [ ] Mise à jour état OF

#### Table sous-traitance

**Table à créer : Sous_Traitance**

**Colonnes :**
- ID
- Num_OF
- Sous_Traitant
- Date_Envoi
- Date_Retour_Prevue
- Date_Retour_Reel
- Qte_Envoyee
- Qte_Recue
- Statut (En cours, Terminé, Retard)
- Observations

**Actions :**
- [ ] Créer table
- [ ] Formulaires saisie
- [ ] Requêtes suivi

---

### ✅ Étape 11 : Indicateurs de Performance (KPI)

**Tâche :** Dashboard KPI décisionnel

#### KPI à calculer

**KPI Production :**

1. **Taux respect délais**
   - Formule : (Nb OF livrés à temps / Nb OF livrés) × 100
   - [ ] Requête calcul
   - [ ] Graphique jauge

2. **Taux utilisation machines**
   - Formule : (Heures production réelles / Heures disponibles) × 100
   - [ ] Calcul par machine
   - [ ] Graphique barres

3. **Temps moyen OF**
   - Formule : Moyenne (Date Fin - Date Début) par OF
   - [ ] Calcul
   - [ ] Évolution temporelle

4. **Productivité tisseurs**
   - Formule : Somme pièces produites / Nb jours travaillés
   - [ ] Calcul par tisseur
   - [ ] Classement

5. **Taux rebut**
   - Formule : (Qte Rebut / Qte Produite) × 100
   - [ ] Calcul
   - [ ] Alerte si > 5%

**KPI Stock :**

1. **Taux rotation stock MP**
   - Formule : Valeur consommations / Stock moyen
   - [ ] Calcul (si valeurs disponibles)

2. **Nombre ruptures**
   - Formule : Compte articles avec Stock = 0 et Minimal > 0
   - [ ] Comptage quotidien
   - [ ] Historique

3. **Valeur stock immobilisé**
   - Formule : Somme (Stock × Prix unitaire)
   - [ ] Calcul (si prix disponibles)

**KPI Financiers (si données dispo) :**

1. **Coût production par OF**
   - Formule : Coût MP + Coût MO + Coût machine
   - [ ] Calcul si données disponibles

#### Implémentation Dashboard KPI

**Actions :**
- [ ] Créer page "KPI" dans app web
- [ ] Graphiques interactifs (Chart.js, Plotly)
- [ ] Filtres période, machine, produit
- [ ] Export PDF rapport mensuel
- [ ] Planifier envoi automatique direction (email)

---

## 3.2 FORMATION ET DOCUMENTATION

### ✅ Étape 12 : Documentation Utilisateur

**Tâche :** Créer guides utilisateurs

#### Guides à créer

1. **Guide Magasinier MP**
   - [ ] Réception MP
   - [ ] Scan QR codes
   - [ ] Préparation OF
   - [ ] Transferts entrepôts
   - [ ] Inventaires

2. **Guide Tisseur**
   - [ ] Scan OF départ fabrication
   - [ ] Saisie avancement
   - [ ] Scan OF fin fabrication
   - [ ] Signalement problèmes

3. **Guide Coupeur**
   - [ ] Scan OF
   - [ ] Saisie quantités coupées
   - [ ] Signalement chutes

4. **Guide Contrôleur Qualité**
   - [ ] Checklist contrôle
   - [ ] Scan OF
   - [ ] Saisie validation
   - [ ] Signalement défauts

5. **Guide Responsable Production**
   - [ ] Planification OF
   - [ ] Attribution machines
   - [ ] Suivi tableau de bord
   - [ ] Gestion alertes
   - [ ] Génération dossiers fabrication

6. **Guide Responsable Achats**
   - [ ] Suivi stocks MP
   - [ ] Alertes ruptures
   - [ ] Génération commandes fournisseurs

7. **Guide Administrateur Système**
   - [ ] Configuration Azure AD
   - [ ] Gestion utilisateurs
   - [ ] Maintenance bases de données
   - [ ] Sauvegardes
   - [ ] Résolution problèmes

**Format :**
- [ ] PDF avec captures d'écran
- [ ] Vidéos tutorielles (si possible)
- [ ] FAQ

---

### ✅ Étape 13 : Formation Utilisateurs

**Tâche :** Former les équipes

#### Sessions de formation

**Formation 1 : Magasiniers**
- Durée : 2 heures
- Contenu : Scan, préparation OF, transferts
- [ ] Planifier session
- [ ] Préparer exemples réels
- [ ] Exercices pratiques

**Formation 2 : Tisseurs**
- Durée : 1 heure
- Contenu : Scan OF, saisie production
- [ ] Planifier session
- [ ] Démonstration sur vraie machine

**Formation 3 : Coupeurs**
- Durée : 30 minutes
- Contenu : Scan OF, saisie coupe
- [ ] Planifier session

**Formation 4 : Contrôleurs Qualité**
- Durée : 30 minutes
- Contenu : Checklist, scan, saisie
- [ ] Planifier session

**Formation 5 : Responsable Production**
- Durée : 3 heures
- Contenu : Planification, gestion complète, dashboards
- [ ] Planifier session

**Formation 6 : Responsable Achats**
- Durée : 1 heure
- Contenu : Suivi stocks, alertes, commandes
- [ ] Planifier session

**Actions :**
- [ ] Planifier calendrier formations
- [ ] Préparer supports (slides, exemples)
- [ ] Sessions pratiques hands-on
- [ ] Recueillir feedback utilisateurs
- [ ] Sessions de rattrapage si besoin

---

## 3.3 MISE EN PRODUCTION

### ✅ Étape 14 : Phase Pilote

**Tâche :** Tester système en conditions réelles

#### Préparation pilote

**Actions :**
- [ ] Choisir périmètre pilote (1 machine ? 1 semaine ?)
- [ ] Sélectionner quelques OF test
- [ ] Briefing équipes participantes
- [ ] Préparer suivi incidents

#### Exécution pilote

**Durée :** 1-2 semaines

**Actions :**
- [ ] Lancement production avec nouveau système
- [ ] Accompagnement quotidien utilisateurs
- [ ] Relevé incidents/bugs
- [ ] Ajustements à chaud
- [ ] Collecte feedback

#### Bilan pilote

**Actions :**
- [ ] Réunion bilan avec équipes
- [ ] Liste améliorations nécessaires
- [ ] Décision : go/no-go déploiement complet
- [ ] Ajustements prioritaires avant déploiement

---

### ✅ Étape 15 : Déploiement Complet

**Tâche :** Généraliser système à toute la production

#### Préparation déploiement

**Actions :**
- [ ] Corrections post-pilote
- [ ] Formation utilisateurs restants
- [ ] Communication déploiement (date, modalités)
- [ ] Plan de secours (rollback si problème majeur)

#### Exécution déploiement

**Actions :**
- [ ] Migration complète données
- [ ] Activation tous modules
- [ ] Support renforcé J+1 à J+7
- [ ] Hotline incidents

#### Stabilisation

**Période :** 1 mois post-déploiement

**Actions :**
- [ ] Suivi quotidien utilisation
- [ ] Corrections bugs mineurs
- [ ] Optimisations performances
- [ ] Collecte suggestions améliorations

---

### ✅ Étape 16 : Support et Maintenance

**Tâche :** Assurer pérennité système

#### Support utilisateurs

**Actions :**
- [ ] Définir canal support (email, Teams, téléphone ?)
- [ ] SLA réponse incidents (< 24h ?)
- [ ] Base de connaissances FAQ
- [ ] Hotline pour urgences

#### Maintenance préventive

**Actions :**
- [ ] Planifier sauvegardes régulières (quotidiennes ?)
- [ ] Vérifications périodiques intégrité données
- [ ] Mises à jour bibliothèques/sécurité
- [ ] Tests de restauration (semestriels)

#### Évolutions

**Actions :**
- [ ] Collecte demandes d'évolution utilisateurs
- [ ] Priorisation évolutions
- [ ] Planification développements futurs
- [ ] Communication roadmap

---

# PARTIE 4 : AMÉLIORATIONS RECOMMANDÉES

## 4.1 COURT TERME (0-3 mois)

### 🎯 Priorité 1 : Dossiers de Fabrication Automatisés

**Pourquoi ?** Besoin immédiat, fort impact sur fluidité production

**Actions :**
1. Développer générateur PDF depuis app web
2. Templates 5 pages avec QR codes
3. Intégration avec Base_Commandes
4. Tests et ajustements
5. Déploiement

**Bénéfices :**
- ✅ Gain temps énorme (plus de saisie manuelle)
- ✅ Réduction erreurs
- ✅ Traçabilité parfaite

---

### 🎯 Priorité 2 : Système d'Alertes

**Pourquoi ?** Éviter ruptures et retards

**Actions :**
1. Configurer règles d'alerte
2. Dashboard alertes dans app web
3. Emails automatiques (Power Automate)
4. Tests

**Bénéfices :**
- ✅ Anticipation problèmes
- ✅ Réactivité accrue
- ✅ Moins de stress

---

### 🎯 Priorité 3 : Optimisation Performances Power Query

**Pourquoi ?** Refresh trop lent = frustration

**Actions :**
1. Audit performances actuelles
2. Identifier goulots d'étranglement
3. Refactoring requêtes lentes
4. Activation Query Folding
5. Tests

**Bénéfices :**
- ✅ Refresh rapide (< 30 secondes ?)
- ✅ Meilleure expérience utilisateur
- ✅ Scalabilité

---

## 4.2 MOYEN TERME (3-6 mois)

### 🎯 Planning Production (Gantt)

**Actions :**
1. Développer module Planning dans app web
2. Intégration bibliothèque Gantt
3. Calculs dates prévisionnelles
4. Gestion conflits machines
5. Tests et ajustements

**Bénéfices :**
- ✅ Visibilité planning
- ✅ Optimisation machines
- ✅ Respect délais

---

### 🎯 Module Sous-Traitance

**Actions :**
1. Workflow envoi/suivi/réception
2. Bons de sortie automatiques
3. Tableau de bord sous-traitance
4. Historique performance sous-traitants

**Bénéfices :**
- ✅ Meilleure gestion sous-traitance
- ✅ Traçabilité complète
- ✅ Optimisation choix sous-traitants

---

### 🎯 Dashboard KPI

**Actions :**
1. Définir KPI prioritaires
2. Calculs et requêtes
3. Graphiques interactifs
4. Rapports automatiques direction

**Bénéfices :**
- ✅ Pilotage activité data-driven
- ✅ Identification axes amélioration
- ✅ Communication direction facilitée

---

## 4.3 LONG TERME (6-12 mois)

### 🎯 Module Traçabilité Avancée

**Actions :**
1. Base historique opérations
2. Interfaces recherche multi-critères
3. Graphes de traçabilité visuels
4. Certificats traçabilité automatiques

**Bénéfices :**
- ✅ Traçabilité ultime
- ✅ Conformité normes/certifications
- ✅ Confiance clients

---

### 🎯 Intelligence Artificielle & Prédiction

**Actions (prospectif) :**
1. Algorithmes prédiction délais réels (Machine Learning)
2. Détection automatique défauts qualité (vision par ordinateur)
3. Optimisation planning automatique (IA)
4. Prédiction pannes machines (maintenance prédictive)

**Bénéfices :**
- ✅ Précision accrue
- ✅ Anticipation maximale
- ✅ Réduction coûts

---

### 🎯 Intégration ERP Externe (si nécessaire)

**Si croissance forte :**
- Évaluer solutions ERP du marché (Odoo, SAP, Microsoft Dynamics)
- Migration données actuelles
- Intégration comptabilité, RH, CRM

**Bénéfices :**
- ✅ Système unifié
- ✅ Scalabilité maximale
- ✅ Support éditeur

---

# PARTIE 5 : ROADMAP RÉCAPITULATIVE

## Timeline Complète

### Phase 1 : FONDATIONS (Mois 1-2)
- ✅ Validation/Nettoyage données Excel
- ✅ Configuration Power Query complet
- ✅ Tableaux de bord Excel
- ✅ Configuration app web + Azure AD
- ✅ Déploiement scan mobile

### Phase 2 : AUTOMATISATION (Mois 2-3)
- 🎯 Dossiers fabrication automatisés
- 🎯 Système alertes
- 🎯 Optimisation performances
- 🎯 Formation utilisateurs
- 🎯 Phase pilote

### Phase 3 : OPTIMISATION (Mois 3-6)
- 🎯 Déploiement complet
- 🎯 Planning Gantt
- 🎯 Module sous-traitance
- 🎯 Dashboard KPI
- 🎯 Stabilisation

### Phase 4 : EXCELLENCE (Mois 6-12)
- 🎯 Traçabilité avancée
- 🎯 Historique opérations complet
- 🎯 Amélioration continue
- 🎯 Évolutions utilisateurs

### Phase 5 : INNOVATION (Mois 12+)
- 💡 IA & Prédiction
- 💡 Intégration ERP (si besoin)
- 💡 Automatisation maximale

---

# CONCLUSION

## ✅ Points Forts Actuels

Vous avez déjà mis en place un **système solide et fonctionnel** :

1. ✅ **Traçabilité MP** (QR codes, multi-entrepôts, états stock)
2. ✅ **BOM structuré** (gestion produits composés, sélecteurs S01-S08)
3. ✅ **Suivi production** (tissage, coupe, qualité)
4. ✅ **Calculs automatiques** (besoins MP, temps production, compteur machine)
5. ✅ **Application web** (interface moderne, modules fonctionnels)
6. ✅ **Scan mobile** (préparation, consommation temps réel)

## 🎯 Axes d'Amélioration Prioritaires

Pour **maximiser l'efficacité**, concentrez-vous sur :

1. 🎯 **Dossiers de fabrication automatisés** (impact immédiat)
2. 🎯 **Alertes proactives** (éviter ruptures/retards)
3. 🎯 **Planning Gantt** (optimiser machines, respecter délais)
4. 🎯 **KPI décisionnels** (piloter avec data)

## 💡 Recommandation Stratégique

**Approche progressive :**
- ✅ Ne pas tout faire d'un coup
- ✅ Prioriser par impact/effort
- ✅ Impliquer utilisateurs
- ✅ Itérer et améliorer continuellement

**Philosophie :**
> "Un bon système ERP n'est pas celui qui a toutes les fonctionnalités, mais celui qui est **réellement utilisé** et apporte de la **valeur quotidienne**."

---

## 📞 PROCHAINES ÉTAPES CONCRÈTES

**Semaine 1-2 :**
1. Revoir ce document ensemble
2. Prioriser les fonctionnalités (top 3-5)
3. Valider/Compléter données Excel existantes
4. Décider : développements internes ou aide externe ?

**Semaine 3-4 :**
1. Démarrer développement priorité #1
2. Tests
3. Formation utilisateurs pilotes

**Mois 2 :**
1. Déploiement pilote
2. Ajustements
3. Démarrage priorité #2

**Et la suite...**
- Selon roadmap définie ensemble
- Revues régulières (mensuelles ?)
- Ajustements continus

---

**Prêt à passer à l'action ? 🚀**

Si vous avez des questions sur ce document ou souhaitez approfondir un point spécifique, je suis là pour vous aider !
