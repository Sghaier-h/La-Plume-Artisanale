# 🛍️ GUIDE COMPLET - ARTICLES ET VENTES DANS ODOO
## La Plume Artisanale - Gestion Produits et Commandes Clients

---

## 📋 TABLE DES MATIÈRES

1. [Vue d'Ensemble Flux Commercial](#1-vue-densemble-flux-commercial)
2. [Configuration Module Ventes](#2-configuration-module-ventes)
3. [Création Articles Vendables](#3-création-articles-vendables)
4. [Gestion Variantes Produits](#4-gestion-variantes-produits)
5. [Tarification et Listes de Prix](#5-tarification-et-listes-de-prix)
6. [Catalogue Produits](#6-catalogue-produits)
7. [Gestion Clients](#7-gestion-clients)
8. [Processus de Vente](#8-processus-de-vente)
9. [Devis et Commandes](#9-devis-et-commandes)
10. [Intégration Ventes-Fabrication](#10-intégration-ventes-fabrication)
11. [Intégration Ventes-Stock](#11-intégration-ventes-stock)
12. [Livraisons et Expéditions](#12-livraisons-et-expéditions)
13. [Facturation](#13-facturation)
14. [Rapports et Analyses](#14-rapports-et-analyses)
15. [Cas Pratiques](#15-cas-pratiques)

---

# 1. VUE D'ENSEMBLE FLUX COMMERCIAL

## 1.1 Flux Standard de Vente

Voici le processus complet dans Odoo :

```
┌─────────────────────────────────────────────────────────────────┐
│                    FLUX COMMERCIAL COMPLET                       │
└─────────────────────────────────────────────────────────────────┘

1. DEVIS/COMMANDE CLIENT
   ├─ Création devis
   ├─ Envoi au client (email PDF)
   ├─ Validation devis → Commande
   └─ Confirmation commande
         ↓
2. FABRICATION (Si produit "À fabriquer")
   ├─ Création automatique OF
   ├─ Réservation matières premières
   ├─ Production
   └─ Réception produits finis en stock
         ↓
3. LIVRAISON
   ├─ Création automatique bon de livraison
   ├─ Préparation commande (picking)
   ├─ Validation livraison
   └─ Client reçoit produits
         ↓
4. FACTURATION
   ├─ Création facture (auto ou manuelle)
   ├─ Envoi facture au client
   ├─ Enregistrement paiement
   └─ Lettrage comptable
         ↓
5. APRÈS-VENTE
   ├─ Retours clients (si applicable)
   ├─ Avoirs
   └─ SAV
```

## 1.2 Types de Ventes dans Votre Contexte

### Vente Type 1 : Sur Stock

**Exemple :** Client commande 50 Foutas ARTHUR que vous avez en stock

```
Devis → Commande → Livraison immédiate → Facture
(Pas de fabrication)
```

### Vente Type 2 : À Fabriquer

**Exemple :** Client commande 100 Ponchos personnalisés

```
Devis → Commande → OF Automatique → Production → Livraison → Facture
```

### Vente Type 3 : Fabrication pour Stock

**Cas :** Vous anticipez les commandes et fabriquez à l'avance

```
OF Planifié → Production → Stock → Attente commande → Vente
```

---

# 2. CONFIGURATION MODULE VENTES

## 2.1 Activation Module

**Menu :** Applications → Rechercher "Ventes"

- [ ] Installer **Ventes (Sales)**
- [ ] Attendre fin installation

## 2.2 Paramètres Généraux

**Menu :** Ventes → Configuration → Paramètres

### Section : Devis et Commandes

```
☑ Variantes de produits
   → Permet de gérer dimensions/couleurs/finitions comme variantes

☑ Unités de mesure
   → Actif (déjà configuré dans Inventaire)

☑ Dates de livraison
   → Afficher date livraison prévue sur commandes

☑ Conditions générales de vente
   → Ajouter CGV sur devis/factures

☐ Signature en ligne
   → Si vous voulez que clients signent devis en ligne

☐ Paiement en ligne
   → Si vous acceptez paiements en ligne (PayPal, etc.)
```

### Section : Livraison

```
☑ Adresses de livraison clients
   → Permet adresses différentes facturation/livraison

☑ Bons de livraison
   → Génère bons de livraison automatiques

☑ Quantités livrées
   → Suivre quantités réellement livrées vs commandées
```

### Section : Facturation

```
Politique de facturation :
○ Quantités commandées (facturer dès commande)
◉ Quantités livrées (facturer après livraison) ← RECOMMANDÉ
○ Acomptes (si vous prenez des acomptes)
```

**Actions :**
- [ ] Activer options nécessaires
- [ ] Sauvegarder paramètres

## 2.3 Configuration Équipe Commerciale

**Menu :** Ventes → Configuration → Équipes Commerciales

### Créer équipe de vente

```
Nom : Équipe Ventes La Plume
Chef d'équipe : [Responsable commercial]
Membres :
  ├─ [Commercial 1]
  ├─ [Commercial 2]
  └─ [Vous]

Objectif mensuel : [Objectif en TND]

Quotas :
☑ Activer quotas mensuels par commercial
```

**Actions :**
- [ ] Créer équipe(s) de vente
- [ ] Affecter membres

---

# 3. CRÉATION ARTICLES VENDABLES

## 3.1 Structure Produits pour le Textile

### Approche Recommandée : Variantes de Produits

Pour un produit comme la **Fouta ARTHUR**, au lieu de créer :
- ARTHUR 100/200 Blanc
- ARTHUR 100/200 Écru
- ARTHUR 100/200 Beige
- ARTHUR 120/180 Blanc
- ARTHUR 120/180 Écru
- etc. (des centaines d'articles !)

→ Créez **1 produit "Fouta ARTHUR"** avec **variantes** :
- Dimensions (100/200, 120/180, 140/220, etc.)
- Couleurs (Blanc, Écru, Beige, Taupe, etc.)
- Finitions (Frange, Couture, Ourlet)

**Avantages :**
✅ Gestion simplifiée (1 fiche au lieu de 100+)
✅ Catalogue client clair
✅ Prix par variante
✅ Stock par variante
✅ BOM par variante

## 3.2 Créer Attributs de Variantes

**Menu :** Ventes → Configuration → Attributs

### Attribut 1 : Dimensions

```
Nom de l'attribut : Dimensions
Mode d'affichage : Pills (ou Sélection)
Type de variante : Ne créez pas de variantes

Valeurs :
  ├─ 100/200 cm
  ├─ 120/180 cm
  ├─ 140/220 cm
  ├─ 160/260 cm
  └─ ... (toutes vos dimensions)
```

**Créer valeur :**
- Cliquer "Ajouter une ligne"
- Nom : 100/200 cm
- Code interne : 1020 (optionnel)
- Sauvegarder

**Répéter pour toutes dimensions**

### Attribut 2 : Couleur

```
Nom de l'attribut : Couleur
Mode d'affichage : Couleur (si vous voulez affichage visuel)
Type de variante : Ne créez pas de variantes

Valeurs :
  ├─ Blanc (Code : C01, Couleur HTML : #FFFFFF)
  ├─ Écru (Code : C02, Couleur HTML : #F5F5DC)
  ├─ Beige (Code : C03, Couleur HTML : #F5F5DC)
  ├─ Taupe (Code : C04, Couleur HTML : #8B8589)
  └─ ... (toutes vos couleurs)
```

### Attribut 3 : Finition

```
Nom de l'attribut : Finition
Mode d'affichage : Pills
Type de variante : Ne créez pas de variantes

Valeurs :
  ├─ Frange (Code : FR)
  ├─ Couture (Code : COU)
  └─ Ourlet (Code : OU)
```

### Attribut 4 : Nombre de Couleurs (si applicable)

```
Nom de l'attribut : Nombre de Couleurs
Mode d'affichage : Radio

Valeurs :
  ├─ Uni-couleur
  ├─ Bi-couleur
  └─ Multi-couleur
```

**Actions :**
- [ ] Créer tous les attributs nécessaires
- [ ] Créer toutes les valeurs pour chaque attribut

## 3.3 Créer Produit avec Variantes

**Menu :** Ventes → Produits → Créer

### Exemple : Fouta ARTHUR

```
═══════════════════════════════════════════════════════════
ONGLET INFORMATIONS GÉNÉRALES
═══════════════════════════════════════════════════════════

Nom du produit : Fouta ARTHUR
Référence interne : ARTHUR (la variante ajoutera suffixe)

Photo produit : [Uploader photo principale]

Peut être vendu : ☑ Oui
Peut être acheté : ☐ Non (vous le fabriquez)

Catégorie de produit : Produits Finis > Foutas
Type de produit : Stockable

Prix de vente : 0 (sera défini par variante)
Coût : 0 (sera calculé automatiquement depuis BOM)

Taxes client : TVA 19% (ou selon régime)

Unité de mesure : Unité(s)

Description pour devis :
┌─────────────────────────────────────────────────────────┐
│ Fouta ARTHUR - 100% Coton                               │
│                                                          │
│ Caractéristiques :                                      │
│ • Matière : Coton de qualité supérieure                │
│ • Tissage traditionnel tunisien                        │
│ • Dimensions disponibles : 100/200 à 160/260 cm       │
│ • Finitions au choix : Frange, Couture, Ourlet        │
│ • Couleurs variées                                      │
│                                                          │
│ Utilisation : Serviette de plage, fouta hamam, déco   │
│                                                          │
│ Entretien : Lavage machine 40°C                        │
└─────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════
ONGLET VENTES
═══════════════════════════════════════════════════════════

Politique de facturation : Sur quantités livrées

Description pour devis : [Déjà renseignée ci-dessus]

Délai de livraison : 0 jours (si stock) ou 15 jours (si à fabriquer)

═══════════════════════════════════════════════════════════
ONGLET ACHATS
═══════════════════════════════════════════════════════════

[Vide - produit non acheté]

═══════════════════════════════════════════════════════════
ONGLET INVENTAIRE
═══════════════════════════════════════════════════════════

Routes :
☑ Fabriquer (MRP)
☐ Acheter (non)

Traçabilité :
☑ Par numéro de série unique (si traçabilité pièce par pièce)
Ou
☑ Par numéro de lot (si traçabilité par lot production)

Règle de réapprovisionnement : (on configurera après)

Poids : 0.5 kg (poids moyen, ajustable par variante)

═══════════════════════════════════════════════════════════
ONGLET VARIANTES (🔥 IMPORTANT)
═══════════════════════════════════════════════════════════

Cliquer "Ajouter une ligne"

Ligne 1 : Attribut Dimensions
├─ Attribut : Dimensions
├─ Valeurs : [Sélectionner TOUTES] 100/200, 120/180, 140/220, 160/260
└─ Mode de création variante : Instantané (créer toutes combinaisons)

Ligne 2 : Attribut Couleur
├─ Attribut : Couleur
├─ Valeurs : [Sélectionner couleurs disponibles pour ARTHUR]
│   Ex : Blanc, Écru, Beige, Taupe
└─ Mode de création variante : Instantané

Ligne 3 : Attribut Finition
├─ Attribut : Finition
├─ Valeurs : Frange, Couture, Ourlet
└─ Mode de création variante : Instantané
```

**⚠️ ATTENTION :** Si vous avez :
- 4 dimensions × 10 couleurs × 3 finitions = **120 variantes**

Odoo va créer **120 combinaisons automatiquement**.

**Astuce :** Commencez avec un sous-ensemble (ex : 2 dimensions × 3 couleurs × 1 finition = 6 variantes) pour tester.

**Sauvegarder le produit**

### Résultat : Variantes Créées

Après sauvegarde, Odoo crée automatiquement toutes les variantes :

**Menu :** Ventes → Produits → ARTHUR → Variantes (onglet)

Vous verrez :
```
┌─────────────────────────────────────────────────────────────────┐
│ Référence          │ Attributs                  │ Prix │ Stock  │
├────────────────────┼────────────────────────────┼──────┼────────┤
│ ARTHUR-1020-FR-B   │ 100/200, Frange, Blanc    │  0   │   0    │
│ ARTHUR-1020-FR-E   │ 100/200, Frange, Écru     │  0   │   0    │
│ ARTHUR-1020-COU-B  │ 100/200, Couture, Blanc   │  0   │   0    │
│ ARTHUR-1218-FR-B   │ 120/180, Frange, Blanc    │  0   │   0    │
│ ...                │ ...                        │  ... │  ...   │
└─────────────────────────────────────────────────────────────────┘
```

**Actions :**
- [ ] Créer produit ARTHUR avec variantes
- [ ] Vérifier variantes créées
- [ ] Répéter pour autres produits (IBIZA, PONCHO, etc.)

## 3.4 Configuration Variante Individuelle

Cliquer sur une variante (ex : ARTHUR-1020-FR-B) :

```
═══════════════════════════════════════════════════════════
INFORMATIONS VARIANTE
═══════════════════════════════════════════════════════════

Référence interne : ARTHUR-1020-FR-B (auto-générée)
Code-barres : [Générer ou scanner si étiquettes produit fini]

Prix de vente : 35.000 TND (exemple)
Coût : [Auto-calculé depuis BOM]

Photo variante : [Uploader photo spécifique si différente]

Poids : 0.450 kg (ajuster selon dimensions)

Nomenclature (BOM) : [Créer BOM spécifique pour cette variante]
```

**Actions :**
- [ ] Définir prix de vente pour chaque variante
- [ ] Uploader photos produits
- [ ] Créer BOM pour chaque variante

---

# 4. GESTION VARIANTES PRODUITS

## 4.1 BOM par Variante

Chaque variante peut avoir sa propre nomenclature (BOM).

**Menu :** Fabrication → Produits → Nomenclatures → Créer

### BOM pour ARTHUR-1020-FR-B

```
Produit : ARTHUR-1020-FR-B (Fouta ARTHUR 100/200 Frange Blanc)
Quantité : 1
Type : Fabriquer ce produit
Référence : BOM/ARTHUR/1020-FR-B

═══════════════════════════════════════════════════════════
COMPOSANTS
═══════════════════════════════════════════════════════════

Sélecteur S01 : Fil Blanc NM15 (C01_BLANC_NM15-01.00) × 0,850 kg
Sélecteur S02 : Fil Blanc NM15 (C01_BLANC_NM15-01.00) × 0,420 kg
(Si produit uni-couleur, mêmes fils sur plusieurs sélecteurs)

Fournitures :
├─ Étiquette marque × 1 unité
└─ Frange décorative × 2 unités (si applicable)

═══════════════════════════════════════════════════════════
OPÉRATIONS (GAMME)
═══════════════════════════════════════════════════════════

Opération 1 : Tissage
├─ Centre de travail : Machine M2301 (ou "Atelier Tissage")
├─ Durée : 90 minutes (calculé selon duites/vitesse)
├─ Temps setup : 30 minutes

Opération 2 : Contrôle Tissage
├─ Centre de travail : Qualité
├─ Durée : 10 minutes

Opération 3 : Coupe
├─ Centre de travail : Atelier Coupe
├─ Durée : 15 minutes

Opération 4 : Finition Frange
├─ Centre de travail : Atelier Finition
├─ Durée : 20 minutes

Opération 5 : Contrôle Final
├─ Centre de travail : Qualité
├─ Durée : 5 minutes
```

**Actions :**
- [ ] Créer BOM pour chaque variante
- [ ] Ajuster consommations S01-S08 selon produit
- [ ] Définir gammes de fabrication

## 4.2 Prix par Variante

### Option 1 : Prix Fixe par Variante

**Menu :** Ventes → Produits → ARTHUR → Variantes

Cliquer sur chaque variante et définir :
```
ARTHUR-1020-FR-B : 35.000 TND
ARTHUR-1020-FR-E : 35.000 TND
ARTHUR-1218-FR-B : 42.000 TND (plus grande dimension = plus cher)
```

### Option 2 : Prix Dynamique (Supplément par Attribut)

**Menu :** Ventes → Configuration → Attributs → [Attribut] → Valeurs

**Exemple : Dimension 140/220 coûte 10 TND de plus**

```
Attribut : Dimensions
Valeur : 140/220 cm

Prix supplémentaire : +10.000 TND
```

**Résultat :**
```
Prix de base ARTHUR : 35.000 TND
Si dimension 140/220 : 35.000 + 10.000 = 45.000 TND
```

**Actions :**
- [ ] Choisir stratégie de prix
- [ ] Définir prix pour toutes variantes

## 4.3 Stock par Variante

Chaque variante a son propre stock.

**Menu :** Inventaire → Produits → ARTHUR → Variantes → [Variante]

**Onglet Inventaire :**
```
Quantité en stock : [Quantité disponible]
Quantité prévue : [Stock + Achats en cours - Ventes]
```

**Faire inventaire par variante :**

**Menu :** Inventaire → Opérations → Ajustements de Stock

```
Produit : ARTHUR-1020-FR-B
Emplacement : E1/Stock
Quantité comptée : 25
```

---

# 5. TARIFICATION ET LISTES DE PRIX

## 5.1 Prix de Base

Prix défini sur chaque variante (vu ci-dessus).

## 5.2 Listes de Prix (Si Tarification Multiple)

**Si vous avez différents tarifs selon type de client :**
- Prix public
- Prix revendeurs
- Prix export
- Prix grandes quantités

**Menu :** Ventes → Configuration → Listes de prix

### Liste de prix : Revendeurs

```
Nom : Tarif Revendeurs
Devise : TND

Règles de prix :
┌─────────────────────────────────────────────────────────┐
│ Applicable sur    │ Calcul           │ Valeur           │
├───────────────────┼──────────────────┼──────────────────┤
│ Tous produits     │ Remise fixe      │ -20%             │
└─────────────────────────────────────────────────────────┘

Ou règles plus fines :
┌─────────────────────────────────────────────────────────┐
│ Produit : ARTHUR (toutes variantes)                    │
│ Calcul : Prix fixe                                      │
│ Prix : 28.000 TND (au lieu de 35.000)                  │
└─────────────────────────────────────────────────────────┘
```

### Liste de prix : Prix par Quantité

```
Nom : Tarif Grandes Quantités

Règles de prix :
┌─────────────────────────────────────────────────────────┐
│ Produit : ARTHUR                                        │
│ Qté min : 50                                            │
│ Calcul : Remise                                         │
│ Remise : -15%                                           │
└─────────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────────┐
│ Produit : ARTHUR                                        │
│ Qté min : 100                                           │
│ Calcul : Remise                                         │
│ Remise : -25%                                           │
└─────────────────────────────────────────────────────────┘
```

**Affecter liste de prix à un client :**

**Menu :** Ventes → Clients → [Client] → Onglet Ventes et Achats

```
Liste de prix : Tarif Revendeurs
```

**Actions :**
- [ ] Créer listes de prix si nécessaire
- [ ] Définir règles
- [ ] Affecter aux clients concernés

---

# 6. CATALOGUE PRODUITS

## 6.1 Photos Produits

**Importance :** Photos essentielles pour devis PDF et site web (si e-commerce futur)

**Menu :** Ventes → Produits → [Produit] → Photo

- [ ] Uploader photo principale (format carré recommandé, 800×800px minimum)
- [ ] Uploader photos variantes si différentes

**Conseils :**
- Fond blanc pour uniformité
- Haute résolution
- Montrer détails (tissage, finitions)

## 6.2 Description Produits

**Onglet Ventes → Description pour devis**

Rédiger description détaillée qui apparaîtra sur les devis/commandes :

```
Fouta ARTHUR - 100% Coton

✓ Matière : Coton de qualité supérieure, tissage traditionnel
✓ Dimensions : [Variables selon choix client]
✓ Poids : 450g environ
✓ Couleurs : Large gamme disponible
✓ Finitions : Frange, Couture ou Ourlet selon préférence

Caractéristiques :
• Très absorbante
• Séchage rapide
• Légère et compacte
• Fabriquée en Tunisie

Utilisation :
Parfaite comme serviette de plage, fouta hamam, jeté de canapé, 
nappe, paréo, ou élément de décoration.

Entretien :
Lavage machine 40°C. Adoucissant déconseillé pour préserver
l'absorption. Repassage inutile.
```

**Actions :**
- [ ] Rédiger descriptions tous produits
- [ ] Mettre en forme (gras, listes)
- [ ] Traduire en anglais/français si clients internationaux

---

# 7. GESTION CLIENTS

## 7.1 Créer Clients

**Menu :** Ventes → Clients → Créer

### Client Entreprise

```
═══════════════════════════════════════════════════════════
INFORMATIONS GÉNÉRALES
═══════════════════════════════════════════════════════════

Nom : [Raison sociale entreprise]
Type : Entreprise

Adresse : [Adresse complète]
Code postal : [Code]
Ville : [Ville]
Pays : Tunisie (ou autre)

Email : [Email principal]
Téléphone : [Téléphone]
Mobile : [Mobile]
Site web : [URL si applicable]

═══════════════════════════════════════════════════════════
ONGLET CONTACTS
═══════════════════════════════════════════════════════════

Contact 1 : [Nom contact commercial]
├─ Poste : Responsable achats
├─ Email : [Email contact]
└─ Téléphone : [Téléphone direct]

Adresse de livraison : [Si différente de siège]

Adresse de facturation : [Si différente]

═══════════════════════════════════════════════════════════
ONGLET VENTES & ACHATS
═══════════════════════════════════════════════════════════

Commercial : [Affecter commercial responsable compte]

Liste de prix : [Tarif Public ou Tarif Revendeurs selon]

Conditions de paiement : 30 jours fin de mois (exemple)
Ou : Paiement comptant
Ou : 50% acompte, solde à livraison

Mode de livraison : [Transporteur habituel]

Notes internes :
┌─────────────────────────────────────────────────────────┐
│ Client important, préfère être livré le mardi           │
│ Toujours demander facture proforma avant production    │
└─────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════
ONGLET COMPTABILITÉ
═══════════════════════════════════════════════════════════

Matricule fiscal : [Numéro fiscal client]
Registre commerce : [Si applicable]

Compte comptable : [Auto-rempli]

Position fiscale : Régime national (ou autre selon pays)
```

**Sauvegarder**

### Client Particulier

```
Nom : [Prénom Nom]
Type : Particulier

Adresse : [Adresse]
Email : [Email]
Téléphone : [Téléphone]

Liste de prix : Tarif Public
Conditions de paiement : Comptant
```

### Client "STOCK"

**Pour les OF de stock (pas de client final) :**

```
Nom : STOCK - Fabrication pour Stock
Type : Entreprise
Client : ☐ Non
Fournisseur : ☐ Non
Interne : ☑ Oui
```

**Actions :**
- [ ] Créer principaux clients
- [ ] Renseigner contacts
- [ ] Définir conditions commerciales

## 7.2 Segmentation Clients

**Menu :** Ventes → Configuration → Étiquettes de Client

Créer étiquettes pour segmenter :

```
Étiquettes :
├─ 🔵 Revendeur
├─ 🟢 Particulier
├─ 🟡 Export
├─ 🔴 Client VIP
├─ ⚫ Prospect
└─ 🟠 Hôtellerie/Spa
```

**Affecter étiquettes :**

**Menu :** Ventes → Clients → [Client] → Étiquettes

Permet filtrage et analyses par segment.

---

# 8. PROCESSUS DE VENTE

## 8.1 Workflow Standard

```
┌────────────┐     ┌────────────┐     ┌────────────┐
│   DEVIS    │────>│  COMMANDE  │────>│ LIVRAISON  │
│ (Quotation)│     │  (SO)      │     │ (Delivery) │
└────────────┘     └────────────┘     └────────────┘
      │                   │                   │
      │                   │                   │
      v                   v                   v
   Envoi PDF         Création OF        Bon livraison
   au client        (si fabriquer)       + Expédition
      │                   │                   │
      │                   │                   │
      v                   v                   v
 Négociation         Production           Livré
      │                   │                   │
      │                   │                   │
      └──> Validation ────┘                   │
                                              │
                                              v
                                        ┌────────────┐
                                        │  FACTURE   │
                                        │ (Invoice)  │
                                        └────────────┘
                                              │
                                              v
                                         Paiement
```

## 8.2 États des Commandes

**Cycle de vie d'une commande :**

1. **Devis** (Quotation) - État : Draft
   - En cours de rédaction
   - Peut être modifié librement
   - Non comptabilisé

2. **Devis envoyé** - État : Quotation Sent
   - Devis envoyé au client (email PDF)
   - Attente validation client

3. **Commande** - État : Sales Order
   - Client a validé
   - Commande confirmée
   - Déclenche fabrication/réservation stock
   - **⚠️ Modifications limitées après confirmation**

4. **En cours** - État : In Progress
   - OF en production
   - Ou préparation livraison en cours

5. **Livré** - État : Delivered
   - Bon de livraison validé
   - Produits expédiés/livrés

6. **Facturé** - État : Invoiced
   - Facture émise
   - Attente paiement

7. **Payé** - État : Paid
   - Paiement reçu et lettré
   - Commande close

8. **Annulé** - État : Cancelled
   - Commande annulée avant livraison

---

# 9. DEVIS ET COMMANDES

## 9.1 Créer un Devis

**Menu :** Ventes → Commandes → Créer

### En-tête du devis

```
═══════════════════════════════════════════════════════════
INFORMATIONS DEVIS
═══════════════════════════════════════════════════════════

Client : [Sélectionner client dans liste]
   → Odoo pré-remplit automatiquement : adresse, commercial, 
      liste de prix, conditions de paiement

Date de devis : [Aujourd'hui par défaut]

Date de validité : [Aujourd'hui + 30 jours par défaut]

Commercial : [Auto-rempli selon client, modifiable]

Équipe commerciale : [Auto-rempli]

Référence client : [Si le client a son n° de commande]
```

### Lignes de commande

**Cliquer "Ajouter un produit"**

```
┌─────────────────────────────────────────────────────────┐
│ LIGNE 1                                                  │
├─────────────────────────────────────────────────────────┤
│ Produit : [Commencer à taper "ARTHUR"]                  │
│   → Odoo propose : Fouta ARTHUR                         │
│   → Cliquer pour sélectionner                           │
│                                                          │
│ [POPUP Configuration Produit s'ouvre]                   │
│                                                          │
│   Dimensions : ○ 100/200 ◉ 120/180 ○ 140/220           │
│   Couleur : ◉ Blanc ○ Écru ○ Beige ○ Taupe             │
│   Finition : ◉ Frange ○ Couture ○ Ourlet               │
│                                                          │
│   [Bouton : Confirmer]                                  │
│                                                          │
│ → Variante sélectionnée : ARTHUR-1218-FR-B             │
│                                                          │
│ Quantité : 50                                           │
│ Unité : Unité(s)                                        │
│ Prix unitaire : 42.000 TND (prix de la variante)       │
│ Taxes : TVA 19%                                         │
│ Remise : 0% (ou saisir si applicable)                  │
│                                                          │
│ Sous-total : 2,100.000 TND                             │
└─────────────────────────────────────────────────────────┘
```

**Cliquer à nouveau "Ajouter un produit" pour ligne 2**

```
┌─────────────────────────────────────────────────────────┐
│ LIGNE 2                                                  │
├─────────────────────────────────────────────────────────┤
│ Produit : Fouta IBIZA                                   │
│                                                          │
│ [Configuration variante...]                             │
│   Dimensions : ◉ 100/200                                │
│   Couleur : ◉ Écru                                      │
│   Finition : ◉ Ourlet                                   │
│                                                          │
│ Quantité : 30                                           │
│ Prix unitaire : 38.000 TND                              │
│                                                          │
│ Sous-total : 1,140.000 TND                             │
└─────────────────────────────────────────────────────────┘
```

**Répéter pour toutes lignes**

### Bas du devis

```
┌─────────────────────────────────────────────────────────┐
│ TOTAUX                                                   │
├─────────────────────────────────────────────────────────┤
│ Sous-total HT : 3,240.000 TND                           │
│ TVA 19% : 615.600 TND                                   │
│ ────────────────────────────────────────────────────    │
│ TOTAL TTC : 3,855.600 TND                               │
└─────────────────────────────────────────────────────────┘

Autres informations :
├─ Incoterm : [Si export : FOB, CIF, etc.]
├─ Mode de livraison : [Transporteur ou enlèvement client]
└─ Date de livraison prévue : [Calculée auto ou manuelle]
```

### Notes pour le client

```
Conditions de paiement : 30 jours fin de mois
Délai de fabrication : 15 jours ouvrés
Livraison : Franco de port pour commande > 2000 TND

Les produits sont fabriqués sur commande selon vos 
spécifications. Toute annulation après confirmation 
entraînera des frais.
```

**Sauvegarder le devis** (Bouton "Sauvegarder")

**Actions :**
- [ ] Créer devis de test
- [ ] Ajouter plusieurs lignes
- [ ] Vérifier calculs automatiques

## 9.2 Envoyer le Devis au Client

**Bouton "Envoyer par email"**

**Popup Email :**

```
Destinataires : [Email client pré-rempli]

Objet : Votre devis - Fouta ARTHUR et IBIZA

Corps du message :
┌─────────────────────────────────────────────────────────┐
│ Bonjour [Nom Client],                                   │
│                                                          │
│ Veuillez trouver ci-joint notre devis pour votre       │
│ commande de foutas.                                     │
│                                                          │
│ Nous restons à votre disposition pour toute question.  │
│                                                          │
│ Cordialement,                                           │
│ [Votre nom]                                             │
│ La Plume Artisanale                                     │
└─────────────────────────────────────────────────────────┘

Pièces jointes :
☑ Devis_SO001.pdf (généré automatiquement)
☐ Catalogue produits (ajouter si nécessaire)
```

**Cliquer "Envoyer"**

→ Email envoyé au client
→ État du devis passe à "Devis envoyé"
→ Email archivé dans historique (onglet "Chatter")

## 9.3 Suivi du Devis

**Onglet "Chatter" (bas de page) :**

Historique complet :
```
📧 12/11/2025 10:30 - Email envoyé à client@email.com
📝 12/11/2025 10:15 - Devis créé par [Votre nom]
```

**Activités (Rappels) :**

**Bouton "Planifier une activité"**

```
Type : Appel téléphonique
Résumé : Relance client suite devis
Date d'échéance : 19/11/2025 (dans 1 semaine)
Assigné à : [Vous ou commercial]

→ Odoo vous rappellera par notification
```

## 9.4 Confirmer le Devis en Commande

**Scénario :** Client valide le devis (par email, téléphone, etc.)

**Action :** Cliquer bouton **"Confirmer"**

→ **État passe à "Commande"**
→ **Numéro de devis (QT001) devient numéro de commande (SO001)**
→ **Déclenchements automatiques :**

1. **Si produit "À fabriquer" :**
   - Création automatique OF (Ordre de Fabrication)
   - Réservation composants (MP)
   - OF visible dans : Fabrication → Ordres de fabrication

2. **Si produit en stock :**
   - Réservation stock
   - Création bon de livraison (à préparer)

3. **Envoi email confirmation commande au client** (optionnel)

**⚠️ Après confirmation :**
- Modifications limitées (quantités, prix)
- Pour modifications importantes : annuler et recréer
- Ou créer avenant/commande complémentaire

## 9.5 Modifications Après Confirmation

**Si besoin modifier commande confirmée :**

**Option 1 : Débloquer (si pas encore de mouvements)**

**Bouton "Débloquer"** (menu ⋮)
→ Repasse en mode Draft
→ Modifier
→ Re-confirmer

**Option 2 : Créer avenant**

**Bouton "⋮ → Créer avenant"**
→ Crée nouvelle commande liée
→ Ajouter lignes supplémentaires
→ Confirmer avenant

---

# 10. INTÉGRATION VENTES-FABRICATION

## 10.1 Liaison Commande → OF Automatique

**Lorsqu'une commande est confirmée avec un produit "À fabriquer" :**

### Étape 1 : Confirmation Commande

**Menu :** Ventes → Commandes → SO001 → Confirmer

### Étape 2 : OF Créé Automatiquement

**Menu :** Fabrication → Ordres de fabrication

Vous verrez :
```
┌─────────────────────────────────────────────────────────┐
│ Référence : WH/MO/00015                                 │
│ Produit : ARTHUR-1218-FR-B                              │
│ Quantité : 50                                           │
│ Source : SO001 (lien cliquable vers commande)          │
│ Date limite : [Calculée selon date livraison SO]       │
│ État : Brouillon                                        │
└─────────────────────────────────────────────────────────┘
```

### Étape 3 : Confirmer OF

**Cliquer sur OF → Bouton "Confirmer"**

→ Réserve composants (MP)
→ Crée ordres de travail (opérations)
→ Prêt à produire

### Étape 4 : Production

**Suivre workflow OF** (voir guide Odoo principal)

### Étape 5 : Finalisation

**Quand OF terminé :**
→ Produits finis ajoutés au stock
→ **Stock commande SO001 automatiquement disponible**
→ Bon de livraison prêt

## 10.2 Suivi Fabrication depuis Commande

**Menu :** Ventes → Commandes → SO001

**Bouton intelligent "Fabrication"** (en haut)

→ Affiche tous les OF liés à cette commande
→ Voir avancement production en temps réel

**États possibles :**
- ⏳ En attente (OF confirmé mais pas démarré)
- 🔄 En cours (production lancée)
- ✅ Terminé (produits finis)
- ❌ Annulé

## 10.3 Produits Composés

**Exemple :** Commande de Poncho EN (2 tissus C01 + C02)

**Confirmation commande :**
→ Odoo crée **2 OF** (si BOM multi-niveaux) :
  1. OF pour Tissu C01
  2. OF pour Tissu C02

**Une fois les 2 tissus produits :**
→ Odoo crée **OF d'assemblage** (cousage C01+C02)

**Résultat final :**
→ Poncho EN fini
→ Disponible pour livraison

---

# 11. INTÉGRATION VENTES-STOCK

## 11.1 Réservation Stock à la Confirmation

**Quand commande confirmée :**

**Si produit en stock :**
→ Quantité réservée instantanément
→ Stock disponible diminué
→ Stock réservé augmenté

**Exemple :**
```
AVANT confirmation SO001 (50 ARTHUR-1218-FR-B) :
├─ Stock disponible : 100
├─ Stock réservé : 0
└─ Stock physique : 100

APRÈS confirmation :
├─ Stock disponible : 50 (100 - 50)
├─ Stock réservé : 50 (pour SO001)
└─ Stock physique : 100 (inchangé)
```

**Si stock insuffisant :**
→ Réservation partielle
→ Alerte visible sur commande
→ **Bouton "Réapprovisionner"** proposé

## 11.2 Bon de Livraison

**Menu :** Ventes → Commandes → SO001

**Bouton intelligent "Livraison"** (en haut)

→ Affiche bon de livraison **OUT/00X**

### Préparation Livraison

**Menu :** Inventaire → Opérations → Transferts → OUT/00X

```
═══════════════════════════════════════════════════════════
BON DE LIVRAISON OUT/00025
═══════════════════════════════════════════════════════════

Source : SO001
Client : [Nom client]
Adresse de livraison : [Adresse]

Date prévue : 25/11/2025
Transporteur : [Si configuré]

Produits :
┌─────────────────────────────────────────────────────────┐
│ Produit                │ Demandé │ Réservé │ Fait       │
├────────────────────────┼─────────┼─────────┼────────────┤
│ ARTHUR-1218-FR-B       │   50    │   50    │   [ ]      │
│ IBIZA-1020-OU-E        │   30    │   30    │   [ ]      │
└─────────────────────────────────────────────────────────┘

État : Prêt (stock réservé)
```

### Validation Livraison

**En entrepôt, lors de préparation :**

**Option 1 : Scan code-barres**
- Scanner produits un par un
- Odoo coche automatiquement lignes

**Option 2 : Saisie manuelle**
- Cliquer colonne "Fait"
- Saisir quantités préparées

**Une fois tout préparé :**

**Bouton "Valider"**

→ Mouvement de stock effectué (Stock → Expédié)
→ Bon de livraison imprimable (PDF)
→ **Commande SO001 passe à état "Livré"**

## 11.3 Livraisons Partielles

**Scénario :** Stock insuffisant ou livraison échelonnée

**Exemple :**
```
Commande : 100 ARTHUR
Stock actuel : 60
```

**Action :**

1. **Première livraison (60 pièces)**
   - Valider bon livraison OUT/00X avec Qté = 60
   
2. **Commande SO001 :**
   - État : "Partiellement livré"
   - Reste à livrer : 40
   - **Nouveau bon de livraison OUT/00Y créé automatiquement** pour le reliquat

3. **Production des 40 manquantes**
   - OF pour 40 pièces
   - Production
   - Stock à jour

4. **Deuxième livraison (40 pièces)**
   - Valider bon livraison OUT/00Y
   
5. **Commande SO001 :**
   - État : "Livré" (totalement)

---

# 12. LIVRAISONS ET EXPÉDITIONS

## 12.1 Configuration Transporteurs

**Menu :** Inventaire → Configuration → Transporteurs

### Créer transporteur

```
Nom : DHL Express
Société de livraison : DHL
Site web : www.dhl.com
Téléphone : [Contact DHL]

Méthode de tarification :
○ Prix fixe
◉ Basé sur les règles (selon poids, destination)

Règles de tarification :
┌─────────────────────────────────────────────────────────┐
│ Poids de | Poids à | Destination    | Prix            │
├──────────┼─────────┼────────────────┼─────────────────┤
│ 0 kg     │ 10 kg   │ Tunisie        │ 15.000 TND      │
│ 10 kg    │ 30 kg   │ Tunisie        │ 25.000 TND      │
│ 0 kg     │ 10 kg   │ Europe         │ 50.000 TND      │
│ 10 kg    │ 30 kg   │ Europe         │ 80.000 TND      │
└─────────────────────────────────────────────────────────┘
```

**Répéter pour autres transporteurs :**
- Aramex
- Poste Tunisienne
- Transporteur privé local
- Enlèvement client (gratuit)

**Actions :**
- [ ] Créer transporteurs
- [ ] Définir grilles tarifaires
- [ ] Tester calcul frais port

## 12.2 Frais de Port sur Commande

**Lors de création devis/commande :**

**Bouton "Ajouter frais de port"**

→ Odoo calcule automatiquement selon :
- Poids total commande
- Adresse de livraison client
- Grille tarifaire transporteur

**Ligne ajoutée :**
```
┌─────────────────────────────────────────────────────────┐
│ Produit : Livraison DHL Express                         │
│ Quantité : 1                                            │
│ Prix unitaire : 25.000 TND                              │
│ Description : Livraison à [Ville Client]               │
└─────────────────────────────────────────────────────────┘
```

**Ou franco de port :**

Si commande > seuil → Prix livraison = 0

## 12.3 Suivi Colis

**Menu :** Inventaire → Transferts → OUT/00X

**Champ "Numéro de suivi" :**

Saisir numéro tracking transporteur
→ Visible par client si portail activé
→ Lien de suivi automatique (si transporteur supporté)

**Email automatique au client :**

```
Votre commande SO001 a été expédiée !

Transporteur : DHL Express
N° de suivi : 1234567890
Lien de suivi : [Tracking DHL]

Livraison prévue : 20/11/2025
```

---

# 13. FACTURATION

## 13.1 Politique de Facturation

**3 options configurables :**

### Option 1 : Facturer Quantités Commandées

**Paramètres :** Ventes → Configuration → Paramètres → Facturation → Quantités commandées

**Comportement :**
- Facture créée dès confirmation commande
- Montant = Total commande
- Même si pas encore livré

**Usage :** Si vous demandez paiement avant production

### Option 2 : Facturer Quantités Livrées (RECOMMANDÉ)

**Paramètres :** Ventes → Configuration → Paramètres → Facturation → Quantités livrées

**Comportement :**
- Facture créée après validation bon de livraison
- Montant = Quantités réellement livrées
- Si livraison partielle → facture partielle

**Usage :** Standard commerce BtoB

### Option 3 : Acomptes

**Permettre demander acompte :**
- Ex : 50% à la commande, 50% à livraison

## 13.2 Créer Facture

**Menu :** Ventes → Commandes → SO001

**Bouton "Créer facture"**

**Popup Options :**

```
Créer facture :
◉ Facture normale (total commande ou livré)
○ Facture d'acompte (% ou montant fixe)

Si acompte :
  Montant acompte : 50 %
  ou
  Montant fixe : 1500.000 TND

[Bouton : Créer facture]
```

### Facture Générée

**Menu :** Comptabilité → Clients → Factures → INV/2025/0001

```
═══════════════════════════════════════════════════════════
FACTURE INV/2025/0001
═══════════════════════════════════════════════════════════

Client : [Nom client]
Adresse : [Adresse]
Matricule fiscal : [N° fiscal]

Date facture : 15/11/2025
Date d'échéance : 15/12/2025 (selon conditions paiement)

Référence commande : SO001

Lignes facture :
┌─────────────────────────────────────────────────────────┐
│ Description         │ Qté │ Prix U. │ Total HT          │
├─────────────────────┼─────┼─────────┼───────────────────┤
│ ARTHUR-1218-FR-B    │  50 │ 42.000  │ 2,100.000 TND     │
│ IBIZA-1020-OU-E     │  30 │ 38.000  │ 1,140.000 TND     │
│ Livraison DHL       │   1 │ 25.000  │    25.000 TND     │
├─────────────────────┴─────┴─────────┼───────────────────┤
│                        Sous-total HT │ 3,265.000 TND     │
│                             TVA 19%  │   620.350 TND     │
│                        ───────────── │ ───────────────   │
│                            TOTAL TTC │ 3,885.350 TND     │
└──────────────────────────────────────┴───────────────────┘

Conditions de paiement : 30 jours fin de mois
Mode de règlement : Virement bancaire

Coordonnées bancaires :
IBAN : TN59 XXXX XXXX XXXX XXXX XXXX
BIC : XXXXXXXX
Banque : [Nom banque]
```

**Bouton "Confirmer"** → Facture validée (non modifiable)

**Bouton "Envoyer par email"** → Envoi au client

## 13.3 Enregistrer Paiement

**Quand client paie :**

**Menu :** Comptabilité → Clients → Factures → INV/2025/0001

**Bouton "Enregistrer un paiement"**

```
Date : 10/12/2025
Journal : Banque (ou Caisse si espèces)
Montant : 3,885.350 TND
Mémo : Virement client ref SO001

[Bouton : Créer paiement]
```

→ Facture passe à état **"Payé"**
→ Commande SO001 passe à état **"Payé"**
→ Écriture comptable automatique

## 13.4 Factures Partielles

**Si livraisons multiples :**

**Exemple :**
```
Commande : 100 pièces
Livraison 1 : 60 pièces
Livraison 2 : 40 pièces
```

**Facturation :**

1. **Après livraison 1 :**
   - Créer facture
   - Odoo facture automatiquement 60 pièces
   - Facture INV/2025/0001 pour 60 pièces

2. **Après livraison 2 :**
   - Créer facture (bouton à nouveau disponible)
   - Facture INV/2025/0002 pour 40 pièces

3. **Total facturé = 100 pièces** ✓

---

# 14. RAPPORTS ET ANALYSES

## 14.1 Rapports Ventes

**Menu :** Ventes → Rapports → Ventes

### Analyse Ventes

**Vue Graphique :**
- Graphique barres : CA par mois
- Graphique secteurs : Répartition par produit
- Graphique lignes : Évolution dans le temps

**Filtres disponibles :**
```
Période : Ce mois / Ce trimestre / Cette année
Équipe commerciale : Toutes / Équipe X
Commercial : Tous / [Nom]
Produit : Tous / ARTHUR / IBIZA / etc.
Client : Tous / [Client X]
État : Tous / Devis / Commandes / Facturés
```

**Grouper par :**
- Commercial
- Équipe
- Produit
- Catégorie produit
- Client
- Pays
- Mois

**Mesures :**
- Montant non taxé
- Montant total
- Marge (si coûts renseignés)
- Quantité
- Nombre de commandes

**Actions :**
- [ ] Explorer rapports ventes
- [ ] Créer tableaux de bord favoris
- [ ] Exporter Excel pour analyses poussées

## 14.2 Pipeline Commercial

**Menu :** Ventes → Mon Pipeline

**Vue Kanban :**

```
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│  DEVIS   │  │ DEVIS    │  │ COMMANDES│  │  GAGNÉ   │
│          │  │ ENVOYÉS  │  │          │  │          │
├──────────┤  ├──────────┤  ├──────────┤  ├──────────┤
│ SO001    │  │ SO005    │  │ SO002    │  │ SO003    │
│ 1200 TND │  │ 3500 TND │  │ 2800 TND │  │ 5000 TND │
│          │  │          │  │          │  │          │
│ SO006    │  │ SO008    │  │ SO007    │  │ SO004    │
│ 850 TND  │  │ 1200 TND │  │ 4200 TND │  │ 3200 TND │
└──────────┘  └──────────┘  └──────────┘  └──────────┘
 Total:        Total:        Total:        Total:
 2050 TND      4700 TND      7000 TND     8200 TND
```

**Glisser-déposer** cartes pour changer étapes

**Cliquer carte** pour ouvrir détails

## 14.3 Rapport Produits Vendus

**Menu :** Ventes → Rapports → Produits Vendus

**Vue Tableau :**

```
┌────────────────────┬──────────┬──────────┬─────────────┐
│ Produit            │ Quantité │ CA HT    │ Nb Commandes│
├────────────────────┼──────────┼──────────┼─────────────┤
│ ARTHUR-1218-FR-B   │   450    │ 18,900   │     15      │
│ ARTHUR-1020-FR-B   │   320    │ 11,200   │     12      │
│ IBIZA-1020-OU-E    │   280    │  9,520   │      9      │
│ PONCHO-EN-COU      │   150    │ 12,000   │      8      │
└────────────────────┴──────────┴──────────┴─────────────┘
```

**Analyses possibles :**
- Top 10 meilleures ventes
- Produits à faible rotation (à arrêter ?)
- Saisonnalité (ventes par mois/produit)

## 14.4 Clients Principaux

**Menu :** Ventes → Rapports → Clients

```
┌────────────────────┬──────────┬────────────┬──────────┐
│ Client             │ CA Total │ Nb Cmd     │ CA Moyen │
├────────────────────┼──────────┼────────────┼──────────┤
│ Hotel Miramar      │ 45,000   │    12      │  3,750   │
│ Boutique Souk      │ 32,000   │    18      │  1,778   │
│ Export France SA   │ 28,000   │     3      │  9,333   │
└────────────────────┴──────────┴────────────┴──────────┘
```

**Segmentation :**
- Clients VIP (CA > X)
- Clients à risque (pas commandé depuis 6 mois)
- Prospects (devis mais pas commande)

---

# 15. CAS PRATIQUES

## 15.1 Cas 1 : Vente Simple sur Stock

**Contexte :**
- Client : Boutique Souk
- Produit : 20 ARTHUR-1020-FR-B (en stock)
- Paiement : 30 jours

**Étapes :**

1. **Créer devis**
   - Client : Boutique Souk
   - Produit : ARTHUR-1020-FR-B × 20
   - Prix : 35.000 TND/u = 700.000 TND HT

2. **Envoyer devis**
   - Bouton "Envoyer par email"
   - Client valide par retour

3. **Confirmer commande**
   - Bouton "Confirmer"
   - État : Commande (SO001)
   - Stock réservé : 20 pièces

4. **Préparer livraison**
   - Menu Inventaire → Transferts → OUT/001
   - Préparer colis
   - Scanner produits ou cocher manuellement
   - Valider livraison

5. **Créer facture**
   - Sur SO001, bouton "Créer facture"
   - Facture INV/2025/0001
   - Confirmer et envoyer au client

6. **Enregistrer paiement** (30 jours plus tard)
   - Sur facture, bouton "Enregistrer paiement"
   - Journal : Banque
   - Montant : 833.000 TND TTC
   - Valider

**Résultat :** Commande clôturée, client et Odoo satisfaits ✅

## 15.2 Cas 2 : Vente avec Fabrication

**Contexte :**
- Client : Hotel Miramar
- Produit : 100 IBIZA-1218-OU-B (pas en stock)
- Fabrication nécessaire

**Étapes :**

1. **Créer devis et confirmer** (idem cas 1)
   - SO002 confirmée

2. **OF créé automatiquement**
   - Menu Fabrication → OF
   - WH/MO/00020 pour 100 IBIZA-1218-OU-B
   - Source : SO002

3. **Confirmer OF**
   - Réservation MP
   - Création ordres de travail

4. **Production**
   - Tissage (Machine M2305)
   - Contrôle
   - Coupe
   - Finition Ourlet
   - Contrôle final
   - Produire : 100 pièces → Stock

5. **Livraison** (idem cas 1)
   - Préparation
   - Validation OUT/002

6. **Facturation et paiement** (idem cas 1)

**Résultat :** Fabrication intégrée dans flux commercial ✅

## 15.3 Cas 3 : Produit Composé

**Contexte :**
- Client : Export France SA
- Produit : 50 Poncho EN Couture (2 tissus C01 + C02)

**Étapes :**

1. **Devis et commande** (idem)
   - SO003 pour 50 Poncho EN

2. **OF créés** (BOM multi-niveaux)
   - WH/MO/00021 : 50 Tissu Poncho C01
   - WH/MO/00022 : 50 Tissu Poncho C02
   - WH/MO/00023 : 50 Poncho EN (assemblage, en attente C01+C02)

3. **Production C01**
   - Tissage C01 sur Machine Jacquard
   - 50 tissus C01 → Stock

4. **Production C02**
   - Tissage C02 sur Machine Jacquard
   - 50 tissus C02 → Stock

5. **Assemblage** (automatiquement déclenché)
   - OF 00023 passe en "Prêt"
   - Consomme 50 C01 + 50 C02
   - Opération : Couture assemblage
   - Produit 50 Poncho EN finis → Stock

6. **Livraison et facturation** (idem cas 1)

**Résultat :** BOM multi-niveaux géré automatiquement ✅

## 15.4 Cas 4 : Acompte

**Contexte :**
- Client : Grande commande 200 pièces
- Demande 50% acompte avant production

**Étapes :**

1. **Devis et confirmation**
   - SO004 pour 200 pièces = 14,000 TND HT

2. **Facture d'acompte**
   - Bouton "Créer facture" → Acompte 50%
   - Facture INV/2025/0010 pour 7,000 TND
   - Envoyer au client

3. **Client paie acompte**
   - Enregistrer paiement 7,000 TND

4. **Production** (après réception acompte)
   - Lancer OF
   - Fabrication

5. **Livraison**
   - Validation OUT

6. **Facture solde**
   - Bouton "Créer facture" → Facture normale
   - Odoo déduit automatiquement acompte déjà facturé
   - Facture INV/2025/0011 pour 7,000 TND (solde)
   - Envoyer au client

7. **Client paie solde**
   - Enregistrer paiement 7,000 TND

**Résultat :** Gestion acompte intégrée ✅

## 15.5 Cas 5 : Retour Client

**Contexte :**
- Client retourne 5 pièces défectueuses

**Étapes :**

1. **Créer retour**
   - Menu : Inventaire → Opérations → Retours
   - Ou sur commande SO001 → Bouton "Retour"

2. **Sélectionner produits à retourner**
   - ARTHUR-1020-FR-B × 5
   - Raison : Défaut qualité

3. **Réception retour**
   - Valider réception
   - Produits retournés en stock (ou mis au rebut)

4. **Avoir**
   - Bouton "Créer avoir"
   - Avoir sur facture INV/2025/0001
   - Montant : 5 × 35 = 175 TND HT
   - Confirmer et envoyer

5. **Remboursement client**
   - Enregistrer remboursement
   - Ou garder en crédit pour prochaine commande

**Résultat :** Retour géré avec traçabilité ✅

---

# CONCLUSION

## ✅ Récapitulatif

Avec ce guide, vous savez maintenant :

1. **Configurer module Ventes**
   - Paramètres, équipes, politiques

2. **Créer articles vendables**
   - Avec variantes (dimensions, couleurs, finitions)
   - Prix, photos, descriptions

3. **Gérer clients**
   - Création, segmentation, conditions commerciales

4. **Processus de vente complet**
   - Devis → Commande → Fabrication → Livraison → Facture → Paiement

5. **Intégrations**
   - Ventes ↔ Fabrication (OF automatiques)
   - Ventes ↔ Stock (réservations, livraisons)
   - Ventes ↔ Comptabilité (factures, paiements)

6. **Analyses et rapports**
   - CA, meilleures ventes, clients principaux

## 🎯 Prochaines Étapes

1. **Créer vos produits avec variantes**
   - Commencer avec 1-2 produits pour tester
   - Puis déployer pour tout le catalogue

2. **Importer clients existants**
   - Préparer fichier Excel
   - Import massif

3. **Tester flux complet**
   - Créer devis de test
   - Confirmer → OF → Production → Livraison → Facture

4. **Former équipe commerciale**
   - Session pratique sur cas réels
   - Support pendant première semaine

5. **Déploiement progressif**
   - Commencer avec nouveaux clients
   - Puis migrer clients existants

## 💡 Conseils Finaux

**Simplicité :**
- Commencez simple (produits avec variantes, pas trop complexe)
- Ajoutez fonctionnalités au fur et à mesure

**Cohérence :**
- Nomenclature articles cohérente
- Conventions nommage (ex : ARTHUR-1020-FR-B)

**Documentation :**
- Photos produits de qualité = ventes facilitées
- Descriptions détaillées = moins de questions clients

**Formation :**
- Former TOUTE l'équipe commerciale
- Créer mini-guide interne

**Support :**
- Je reste disponible pour questions !

---

**Prêt à booster vos ventes avec Odoo ? 🚀**

Si vous avez des questions sur ce guide ou besoin d'aide pour la mise en place, n'hésitez pas !
